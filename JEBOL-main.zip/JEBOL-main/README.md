

# INSTALL
```
➠pkg update && pkg upgrade 
➠pkg install python2
➠pkg install git
➠pip2 install requests
➠pip2 install mechanize
➠git clone https://github.com/Bangsat-XD/JEBOL
➠cd JEBOL
➠python2 Bangsat.py
```

***Peringatan !!!***

***Cuman Work di akun Facebook baru kalau akun lama kaga work***

# SCREENSHOT

![Screenshot_20211105-123955_Termux](https://user-images.githubusercontent.com/93072215/140465733-1069b7fd-e265-4484-9854-8286fd72b33c.jpg)
