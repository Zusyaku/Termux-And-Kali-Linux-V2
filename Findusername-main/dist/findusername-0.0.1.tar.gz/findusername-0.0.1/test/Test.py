import unittest

class Test(unittest.TestCase):
    def instagram(self):
        self.assertTrue(True)
    def facebook(self):
        self.assertTrue(True)
    def pinrest(self):
        self.assertTrue(True) 
        
if __name__=="__main__":
    unittest.main()       
    

