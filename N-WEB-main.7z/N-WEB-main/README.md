# N-WEB [ 1.2.2 ]
<b>ADVANCE WEB PENETRATION TESTING TOOL</b>
<br>

<br>
<b><h1>Features 🎭</h1></b>
<li><b>Admin Panel Finder</b></li>
<li><b>Admin Scanner</li></b>
<li><b>Dork Generator</b></li>
<li><b>Advance Dork Finder</li></b>
<li><b>Extract Links</li></b>
<li><b>No Redirect</li></b>
<li><b>Hash Crack (Online-Database)</li></b>
<li><b>Hash Crack (Wordlist)</li></b>
<li><b>Whois Lookup</li></b>
<li><b>Tcp Port Scan</li></b>
<li><b>Geo IP Lookup</li></b>
<li><b>Reserve Analysts Search</li></b>
<li><b>Csrf Vernavility Checker</li></b>
<li><b>Dns-Lookup,Zone-Transfer,Reserve-IP-Lookup,Http-Headers,Subnet-Lookup</li></b>
<li><b>WordPress Username Finder</li></b>
<li><b>WP Scan</li></b>
<li><b>Wp BruteForce </li></b>
<li><b>Sqli Scanner</li></b>
<li><b>Directory BruteForce </li></b>

<h3><b>📸Screenshot : </b></h3>
<br>
<img src="https://github.com/Nabil-Official/N-WEB/blob/main/n-weblast%20(2).png?raw=true">
<br>
<br>
<h2><b>[+] INSTALLATION : </b></h2>
<h3><b>apt update && apt upgrade</b></h3>
<h3><b>pkg install git -y</b></h3>
<h3><b>pkg install python && pkg install python2 -y</b></h3>
<h3><b>pkg install php -y</b></h3>
<h3><b>pkg install nmap -y</b></h3>
<h3><b>git clone https://github.com/Nabil-Official/N-WEB</b></h3>
<h3><b>cd N-WEB</b></h3>
<h3><b>pip2 install -r requirements.txt</b></h3>
<h2><i>[+] For Run :</i></h2>
<h3><b>python2 n-web.py</b></h3>
<br>
<h2> It Provide Only For Legal Activities | If You Misuse It We Are Not Responsible For This</h2>
<br>
<h1><i>🔰 DEVELOPER :</h1></i>
<in><li><a href="https://m.facebook.com/nabil.404"><i>Nabil-Rahman (3RR0R)</i></a></i></li>
