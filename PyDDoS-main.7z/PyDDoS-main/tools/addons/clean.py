import os

if os.name == "nt":
    os.system("@cls & @title PyDDoS & @color e")
else:
    os.system("clear")
