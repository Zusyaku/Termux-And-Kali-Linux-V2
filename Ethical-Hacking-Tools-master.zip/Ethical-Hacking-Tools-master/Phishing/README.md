- [ShellPhish](https://github.com/Kushagrasaxena-13/ShellPhish) [![](https://raw.githubusercontent.com/hhhrrrttt222111/Ethical-Hacking-Tools/master/0/github.png?token=AKLVDP4M2RTUFTJVE5QLRV26WYYCE)](https://github.com/Kushagrasaxena-13/ShellPhish)
```
bash shellphish.sh
```
- [blackeye](https://github.com/An0nUD4Y/blackeye)[![](https://raw.githubusercontent.com/hhhrrrttt222111/Ethical-Hacking-Tools/master/0/github.png?token=AKLVDP4M2RTUFTJVE5QLRV26WYYCE)](https://github.com/An0nUD4Y/blackeye) [![watch](https://raw.githubusercontent.com/hhhrrrttt222111/Ethical-Hacking-Tools/master/0/yt.png?token=AKLVDPZPTF4VDCZFD3CFVAK6WVY3S)](https://youtu.be/u9dBGWVwMMA)
- [HiddenEye Legacy](https://github.com/DarkSecDevelopers/HiddenEye-Legacy)[![](https://raw.githubusercontent.com/hhhrrrttt222111/Ethical-Hacking-Tools/master/0/github.png?token=AKLVDP4M2RTUFTJVE5QLRV26WYYCE)](https://github.com/DarkSecDevelopers/HiddenEye-Legacy) [![watch](https://raw.githubusercontent.com/hhhrrrttt222111/Ethical-Hacking-Tools/master/0/yt.png?token=AKLVDPZPTF4VDCZFD3CFVAK6WVY3S)](https://youtu.be/kNyIrsvuv2s)
