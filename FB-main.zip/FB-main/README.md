<h1 align="center">
  FB
</h1>
</div>
<p align="center">
  Made with ❤️ by <a href="https://github.com/Aldi098">Aldi Bachtiar rifai_</a>
</p>
<p align="center">
 
### Menu
 <img src="https://github.com/COINTER-team/FB/blob/main/hasil%204.png" width="440" title="Menu" alt="Menu">
</p>

## install
```python3
$ pkg install python
$ pkg install python2
$ pkg install nano
$ pkg install git
$ pip2 install requests
$ pip2 install mechanize
$ pip2 install bs4
$ git clone https://github.com/COINTER-team/FB
$ cd FB
$ python2 mulai.py

```

## fungsi
- [x] Crak Daftar teman
- [x] Crak Daftar teman Publik
- [x] Cek hasil Crak CP / OK

> jika script nya eror jangan salah kan Miminnya aga lol 😂😂😂

## Thanks for you
```php
 Polygon
 Dan semua team COINTER-TEAM
```
## Support Me On
<b>• [Youtube](https://youtube.com/channel/UC7ygjAbDjuiN76PqOlJm40A)</b>
</br>
## WhatsApp
<b>• [WhatsApp](https://api.whatsapp.com/send?phone=+62852-9500-4078&text=Assalamualaikum)</b>
<br>
