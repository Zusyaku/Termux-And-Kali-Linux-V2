# Exif-Tool Original >> extrayendo meta datos de fotos

# Esta herramienta nos permite ver los meta datos de una foto 
# Programado en perl (ojo) Esta herramienta no es mia
![metadatos](https://user-images.githubusercontent.com/46208706/57321821-5e059780-70bf-11e9-9c2a-7dcb6e070c6c.jpg)


# Se ejecuta como ?

# perl exiftool (ruta de la fotografia)
# ejemplo
# ![Screenshot_20190507-115330](https://user-images.githubusercontent.com/46208706/57322103-fdc32580-70bf-11e9-8359-fab8ac8831d2.png)

# Contactame : https://t.me/CesarGray
# YouTube : https://www.youtube.com/channel/UCjs0N8PbEo-se0r_4O_svNQ
