#!/usr/bin/bash

# Extrae los meta datos de una foto !!!

# Exif-Tool original



z="
";Wz=' exi';Kz='perl';gz='in';Iz='inst';rz='FIX/';yz='nish';jz='xift';Uz='chmo';BBz='"';Tz='rmux';Cz='upda';oz='ol/e';xz=' "fi';cz='m.te';mz='/Exi';fz='sr/b';ez='es/u';az='/dat';sz='bin';Lz=' -y';pz='ool ';ABz='ed  ';dz='/fil';Fz='upgr';vz='Tool';Yz='cd /';Qz='/exi';Rz='ftoo';tz='cd E';Sz='l-te';Bz='get ';wz='echo';hz='rm -';lz='cp $';Xz='l';Gz='ade ';iz='rf e';uz='xif-';Dz='te -';qz='$PRE';Vz='d +x';Az='apt-';nz='f-To';Jz='all ';Pz='HOME';Oz='cd $';Zz='data';Hz='-y';kz='ool';Ez='y';Mz='pyth';bz='a/co';Nz='on2 ';
eval "$Az$Bz$Cz$Dz$Ez$z$Az$Bz$Fz$Gz$Hz$z$Az$Bz$Iz$Jz$Kz$Lz$z$Az$Bz$Iz$Jz$Mz$Nz$Hz$z$Oz$Pz$z$Oz$Pz$Qz$Rz$Sz$Tz$z$Uz$Vz$Wz$Rz$Xz$z$Yz$Zz$az$bz$cz$Tz$dz$ez$fz$gz$z$hz$iz$jz$kz$z$lz$Pz$mz$nz$oz$jz$pz$qz$rz$sz$z$Oz$Pz$z$tz$uz$vz$z$wz$z$wz$z$wz$xz$yz$ABz$BBz"
