## Developments to be made: 

1-SIP-ENUM will be integrated
2-SIP-ASP will be integrated
   a) Incomplete INVITE transaction DDoS with non-responding destination attack
   b) Incomplete INVITE dialog DDoS without ACK attack
3-The features to add to SIP-DAS
   a) Fragmentation and custom MTU value set support
   b) Network level IP spoofing support
   c) Instrumentation
4-Verbose mode support
5-Input validation should be performed
6-The whole code should be reviewed for all possibilities and exceptions

