#!/usr/bin/env python
# coding:utf-8
# pydictor __init__.py file
# lib directory contains some component of pydictor
"""
Copyright (c) 2016-2017 pydictor developers (https://github.com/LandGrey/pydictor)
License: GNU GENERAL PUBLIC LICENSE Version 3
"""
