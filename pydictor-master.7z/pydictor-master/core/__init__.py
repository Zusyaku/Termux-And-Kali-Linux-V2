#!/usr/bin/env python
# coding:utf-8
# pydictor __init__.py file
# core directory contains some core password-generator function
"""
Copyright (c) 2016-2017 pydictor developers (https://github.com/LandGrey/pydictor)
License: GNU GENERAL PUBLIC LICENSE Version 3
"""
