# instagram-bruteforcer
A brute force tool to hack Instagram accounts

# This tool runs a long list of word list to be able to generate password and so it will take a lot of time to bruteforcer the account
_Bruteforcer method could take days, weeks, months, years depending on strength of the account password_

# Installation in termux
===========================
> pkg upgrade 

> pkg update

> pkg install git

> git clone https://github.com/TermuxHackz/instagram-bruteforcer

> cd instagram-bruteforcer

> chmod +x IBF.py

> python3 IBF.py


**NOTE**
*Pass list: pass.txt*

# Made by AnonyminHack5

# Join our WhatsApp group:
https://chat.whatsapp.com/FfaBEji7JX8H84UFCSoox0

Happy hacking fellow hackers
