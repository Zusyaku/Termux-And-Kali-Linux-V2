class info:
    author      = "Karim shoair (D4Vinci)"
    description = "List all network interfaces and IP."
    function    = "PrivEsc"
    liner       = 'Get-NetIPConfiguration | ft InterfaceAlias,InterfaceDescription,IPv4Address'
