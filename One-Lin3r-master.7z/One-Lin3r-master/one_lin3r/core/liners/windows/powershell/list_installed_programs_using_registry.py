class info:
    author      = "Karim shoair (D4Vinci)"
    description = "List all installed programs from registry."
    function    = "PrivEsc"
    liner       = "Get-ChildItem -path Registry::HKEY_LOCAL_MACHINE\SOFTWARE | ft Name"
