class info:
    author      = "Karim shoair (D4Vinci)"
    description = "List all startup tasks using wmic"
    function    = "PrivEsc"
    liner       = 'wmic startup get caption,command'
