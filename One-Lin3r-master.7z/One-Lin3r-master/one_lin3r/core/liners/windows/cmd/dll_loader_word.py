class info:
    author      = "Karim shoair (D4Vinci)"
    description = "Using microsoft's office word to load a dll file!"
    function    = "Loader"
    liner       = """winword /l FILE_PATH"""
