class info:
    author      = "Karim shoair (D4Vinci)"
    description = "Using runas with a provided set of credentials to execute a command."
    function    = "Execute"
    liner       = 'C:\Windows\System32\runas.exe /env /noprofile /user:USERNAME PASSWORD "COMMAND"'
