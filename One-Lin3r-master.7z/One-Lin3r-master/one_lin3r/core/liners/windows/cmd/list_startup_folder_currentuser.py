class info:
    author      = "Karim shoair (D4Vinci)"
    description = "List all startup tasks depending on the startup folder for current user"
    function    = "PrivEsc"
    liner       = 'dir "C:\Documents and Settings\%username%\Start Menu\Programs\Startup"'
