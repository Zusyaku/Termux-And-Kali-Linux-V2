class info:
    author      = "Karim shoair (D4Vinci)"
    description = "List all users with whoami"
    function    = "PrivEsc"
    liner       = 'whoami /all'
