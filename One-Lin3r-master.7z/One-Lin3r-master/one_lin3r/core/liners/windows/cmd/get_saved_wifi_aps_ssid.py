class info:
    author      = "Karim shoair (D4Vinci)"
    description = "One liner to find all aps ssid"
    function    = "PrivEsc"
    liner       = "netsh wlan show profile"
