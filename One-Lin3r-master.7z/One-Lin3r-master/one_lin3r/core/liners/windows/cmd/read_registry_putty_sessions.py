class info:
    author      = "Karim shoair (D4Vinci)"
    description = "Query putty key from the registry to get putty clear text proxy credentials"
    function    = "PrivEsc"
    liner       = 'reg query "HKCU\Software\SimonTatham\PuTTY\Sessions"'
