class info:
    author      = "Karim shoair (D4Vinci)"
    description = "Silently install a local msi file."
    function    = "Execute"
    liner       = "msiexec /quiet /qn /i FILE_PATH"
