class info:
    author      = "Karim shoair (D4Vinci)"
    description = "List all network shares"
    function    = "PrivEsc"
    liner       = 'net share'
