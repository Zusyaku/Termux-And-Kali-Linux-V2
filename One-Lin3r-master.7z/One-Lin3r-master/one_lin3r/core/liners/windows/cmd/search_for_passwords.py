class info:
    author      = "Karim shoair (D4Vinci)"
    description = "Search for passwords in file contents"
    function    = "PrivEsc"
    liner       = 'findstr /si password *.xml *.ini *.txt *.config'
