class info:
    author      = "Karim shoair (D4Vinci)"
    description = "List all network interfaces, IP, and DNS."
    function    = "PrivEsc"
    liner       = 'ipconfig /all'
