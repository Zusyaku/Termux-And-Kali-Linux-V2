class info:
    author      = "Karim shoair (D4Vinci)"
    description = "Extract patchs and updates from wmic"
    function    = "PrivEsc"
    liner       = 'wmic qfe'
