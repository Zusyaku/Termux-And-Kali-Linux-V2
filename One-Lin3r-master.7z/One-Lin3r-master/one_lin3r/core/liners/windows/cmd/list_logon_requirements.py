class info:
    author      = "Karim shoair (D4Vinci)"
    description = "List logon requirements"
    function    = "PrivEsc"
    liner       = 'net accounts'
