class info:
    author      = "Karim shoair (D4Vinci)"
    description = "Using wsl to run a python code as root."
    function    = "Execute"
    liner       = "wsl python -c 'COMMAND'"
