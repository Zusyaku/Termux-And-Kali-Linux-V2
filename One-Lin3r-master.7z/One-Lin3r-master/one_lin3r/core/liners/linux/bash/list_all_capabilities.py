class info:
    author      = "Karim shoair (D4Vinci)"
    description = "List all capabilities for all binaries (even ones outside bin folder ofc)"
    function    = "PrivEsc"
    liner       = 'getcap -r / 2>/dev/null'
