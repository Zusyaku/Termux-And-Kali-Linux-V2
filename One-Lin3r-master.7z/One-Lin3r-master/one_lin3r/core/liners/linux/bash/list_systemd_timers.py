class info:
    author      = "Karim shoair (D4Vinci)"
    description = "List all timers for systemd using systemctl ofc!"
    function    = "PrivEsc"
    liner       = 'systemctl list-timers --all'
