class info:
    author      = "Karim shoair (D4Vinci)"
    description = "List all crob jobs for current user"
    function    = "PrivEsc"
    liner       = 'crontab -l'
