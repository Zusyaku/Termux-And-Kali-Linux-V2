class info:
    author      = "Karim shoair (D4Vinci)"
    description = "Using nmap to enumerate a website."
    function    = "Nmap script"
    liner       = "nmap --script 'http-enum' -v -p80 -oN http-enum.nmap TARGET"
