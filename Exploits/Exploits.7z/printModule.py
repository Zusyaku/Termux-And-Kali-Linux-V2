# uncompyle6 version 2.11.5
# Python bytecode 2.7 (62211)
# Decompiled from: Python 2.7.18 (default, Apr 20 2020, 20:30:41) 
# [GCC 9.3.0]
# Embedded file name: Exploits\printModule.py
r = '\x1b[31m'
g = '\x1b[32m'
y = '\x1b[33m'
b = '\x1b[34m'
m = '\x1b[35m'
c = '\x1b[36m'
w = '\x1b[37m'

def Print_Scanning(url, CMS):
    print r + '    [' + y + '*' + r + '] ' + c + url + w + ' [ ' + CMS + ' ]'


def Timeout(url):
    print r + '    [' + y + '*' + r + '] ' + c + url + r + ' [ TimeOut!!/NotValid Url ]'


def Print_NotVuln(NameVuln, site):
    print c + '       [' + y + '-' + c + '] ' + r + site + ' ' + y + NameVuln + c + ' [Not Vuln]'


def Print_Username_Password(username, Password):
    print y + '           [' + c + '+' + y + '] ' + c + 'Username: ' + g + username
    print y + '           [' + c + '+' + y + '] ' + c + 'Password: ' + g + Password


def Print_Vuln(NameVuln, site):
    print c + '       [' + y + '+' + c + '] ' + r + site + ' ' + y + NameVuln + g + ' [Vuln!!]'


def Print_Vuln_index(indexPath):
    print c + '       [' + y + '+' + c + '] ' + y + indexPath + g + ' [Index Uploaded!]'


def Print_vuln_Shell(shellPath):
    print c + '       [' + y + '+' + c + '] ' + y + shellPath + g + ' [Shell Uploaded!]'


def Print_vuln_Config(site):
    print c + '       [' + y + '+' + c + '] ' + y + site + g + ' [Config Downloaded!]'


def returnYes(target, CVE, Name, CMS):
    return [
     '{}{}{}'.format(y, target, w), '{}{}{}'.format(c, CVE, w),
     '{}{}{}'.format(w, Name, w), '{}YES{}'.format(g, w), '{}{}{}'.format(c, CMS, w)]


def returnNo(target, CVE, Name, CMS):
    return [
     '{}{}{}'.format(y, target, w), '{}{}{}'.format(c, CVE, w),
     '{}{}{}'.format(w, Name, w), '{}NO{}'.format(r, w), '{}{}{}'.format(c, CMS, w)]