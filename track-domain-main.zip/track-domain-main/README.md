![p](https://img.shields.io/badge/Program-Bash-blue) 
![p](https://img.shields.io/badge/Made-INDONESIA-red) 
![p](https://img.shields.io/badge/Code-BY%20POLYGON-yellowgreen)

script ini berguna untuk `tracking informasi` dari `domain target`                          

```bash
usage :
```
           
![i](https://github.com/COINTER-team/track-domain/blob/main/Screenshot_20211105-171214.png)



> how to install

```php
$ apt update
$ apt full-upgrade
$ apt install jq
$ apt install gawk
$ apt install git
$ apt install python
$ apt install sed
$ pip install httpie
$ git clone https://github.com/COINTER-team/track-domain
$ cd track-domain
$ bash track-dom.sh
```

## 📱 me akun social 📱
• [github](https://github.com/Bayu12345677)                     
• [youtube](https://m.youtube.com/channel/UCtu-GcxKL8kJBXpR1wfMgWg)
