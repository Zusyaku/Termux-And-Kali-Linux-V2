<h1 align="center">
  obfuscate
</h1>
</div>
<p align="center">
  Made with ❤️ by <a href="https://github.com/Aldi098">Aldi Bachtiar rifai_</a>
</p>
<p align="center">
 
### Menu
 <img src="https://github.com/COINTER-team/obfuscate/blob/main/IMG_20211106_181508.jpg" width="440" title="Menu" alt="Menu">
</p>

## install
```python3
$ pkg install python
$ pkg install python3
$ pkg install nano
$ pkg install git
$ pip install six
$ pip3 install six
$ git clone https://github.com/COINTER-team/obfuscate
$ cd obfuscate
$ python enc.py

```

## fungsi
- [x] obfuscate Script python
- [x] obfuscate python
- [x] obfuscate python3

> jika script nya eror jangan salah kan Miminnya aga lol 😂😂😂

## Thanks for you
```php
 Polygon
 Panglima Jateng
 Dan semua team COINTER-TEAM
```
## Support Me On
<b>• [Youtube](https://youtube.com/channel/UC7ygjAbDjuiN76PqOlJm40A)</b>
</br>
## WhatsApp
<b>• [WhatsApp](https://api.whatsapp.com/send?phone=+62852-9500-4078&text=Assalamualaikum)</b>
<br>
