# Mess-SMTP-Checker
MASS  SMTP VALID INVALID CHECKER.

**First Install PYTHON 3**

## For Linux -
```
pip3 install -r requirement.txt
```
```
pyhton3 smtpcheker.py
```
## For Windows -
```
pip install -r requirement.txt
```
```
smtpcheker.py
```
