sudo apt-get install python3-tk python3-dev scrot
pip3 install tqdm vidstream mss pyautogui pyfiglet termcolor pyinstaller pynput
