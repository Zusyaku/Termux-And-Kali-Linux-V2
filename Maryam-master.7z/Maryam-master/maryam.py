#!/usr/bin/env python3

from maryam import __main__
import sys

if __name__ == '__main__':
	__main__.cui(sys.argv[1:])
