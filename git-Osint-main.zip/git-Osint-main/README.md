<h1 align="center">
   Osint git
</h1>
</div>

<p align="center">
  Code by ⌨ polygon
</p>

dimana kita bisa
mengetahui `informasi`
tentang profile github dengan menggunakan `username`

# tampilan
<p align="center">
<img src="https://github.com/Bayu12345677/git-Osint/blob/main/20211110_122559.png" width="345" title="Menu" alt="Menu">
</p>



<p align="center">
  Me Team
</p>

```python
HELIXS-Crew & COINTER

Aldi, Abdul, Panglima jateng
dan seluruh team HELIXS-Crew & COINTER
```

<p align="center">
  HOW TO INSTALL
</p>

```php
$ apt update
```
```php
$ apt full-upgrade
```
```php
$ apt install git
```
```php
$ apt install figlet toilet
```
```php
$ git clone https://github.com/COINTER-team/git-Osint
```
```php
$ cd git-Osint
```
```php
$ bash setup.txt
```
```php
$ bash grab-git.sh
```
<p align="center">
 FEATURE
</p>

> ➢ Ai Pesan eror                 
> ➢ Free no key            
> ➢ ascii thema              
> ➢           animation loading

########################               
`bagi kalian yg ingin bisa`
`belajar bahasa program silakan cek`

• [helixs.id](https://helixs.id)              
• [alpha code](https://alphacode.pythonanywhere.com)


`dan jangan lupa bantu subscribe`        
`Channel saya :)`

• [youtube](https://youtube.com/channel/UCtu-GcxKL8kJBXpR1wfMgWg)


<p align="center">
  Terimkasi telah berkunjung ☕
</p>
