# PenBox – A Penetration Testing Framework
A Penetration Testing Framework , The Hacker’s Repo our hope is in the last version we will have evry script that a hacker needs
#Information Gathering : 
+ nmap 
+ Setoolkit
+ Port Scanning
+ Host To IP
+ wordpress user enumeration
+ CMS scanner
+ XSStracer - checks remote web servers for Clickjacking, Cross-Frame Scripting, Cross-Site Tracing and Host Header Injection
+ Doork - Google Dorks Passive Vulnerability Auditor 
+ Scan A server's Users

# Password Attacks : 
+ Cupp 
+ Ncrack

# Wireless Testing : 
+ reaver 
+ pixiewps
+ Bluetooth Honeypot GUI Framework

# Exploitation Tools : 
+ Venom
+ sqlmap
+ Shellnoob
+ commix
+ FTP Auto Bypass
+ jboss-autopwn
+ Blind SQL Automatic Injection And Exploit
+ Bruteforce the Android Passcode given the hash and salt
+ Joomla, Mambo, PHP-Nuke, and XOOPS CMS SQL injection Scanner

# Sniffing & Spoofing : 
+ Setoolkit 
+ SSLtrip
+ pyPISHER
+ SMTP Mailer

# Web Hacking : 
+ Drupal Hacking 
+ Inurlbr
+ Wordpress & Joomla Scanner
+ Gravity Form Scanner
+ File Upload Checker
+ Wordpress Exploit Scanner
+ Wordpress Plugins Scanner
+ Shell and Directory Finder
+ Joomla! 1.5 - 3.4.5 remote code execution
+ Vbulletin 5.X remote code execution
+ BruteX - Automatically brute force all services running on a target
+ Arachni - Web Application Security Scanner Framework
+ Sub-domain Scanning
+ Wordpress Scanning
+ Wordpress Username Enumeration
+ Wordpress Backup Grabbing
+ Sensitive File Detection
+ Same-Site Scripting Scanning
+ Click Jacking Detection
+ Powerful XSS vulnerability scanning
+ SQL Injection vulnerability scanning

#Private Tools
+ Get all websites
+ Get joomla websites
+ Get wordpress websites
+ Find control panel
+ Find zip files
+ Find upload files
+ Get server users
+ Scan from SQL injection
+ Scan ports (range of ports)
+ Scan ports (common ports)
+ Get server banner
+ Bypass Cloudflare

#Post Exploitation
+ Shell Checker
+ POET
+ Weeman - Phishing Framework

#Recon
+ Sniper
 
#Installation
git clone https://github.com/x3omdax/PenBox.git 
