
<?php if($feature1==1) { ?>
    <div class="row">
     <input type="hidden" id="download_theme" name="download_theme" value="1"> 	
	   <!-- left column -->
	  <div class="col-dpwap-4"><img src="<?php echo plugin_dir_url( __FILE__ ) . 'images/icon-metagauss-theme.png'; ?>" width=120px;></div>
	   <!-- right column -->
	  <div class="col-dpwap-8">
	  <h4>Download Theme</h4>
       <p>1. Just activate this plugin.<br>
          2. You can see Download link on each theme box on Appearance page.<br>
          3. Click on any of them and that theme’s zip will be downloaded to your computer.<br>
       </p>
      </div>
	</div>
<?php } ?>	
<?php if($feature2==1) { ?>
    <div class="row">
    	<input type="hidden" id="registration_magic" name="registration_magic" value="1"> 	
	   <!-- left column -->
	  <div class="col-dpwap-4"><img src="<?php echo plugin_dir_url( __FILE__ ) . 'images/icon-registration-magic.png'; ?>" width=120px;></div>
	   <!-- right column -->
	  <div class="col-dpwap-8">
	  <h4>RegistrationMagic – Custom Registration Forms and User Login</h4>
       <p>Create customized user WordPress Registration Forms, accept payments, track submissions, manage users, analyze stats, assign user...
       </p>
      </div>
	</div>
<?php } ?>	
<?php if($feature3==1) { ?>
    <div class="row">
    	<input type="hidden" id="profile_grid" name="profile_grid" value="1"> 	
	   <!-- left column -->
	  <div class="col-dpwap-4"><img src="<?php echo plugin_dir_url( __FILE__ ) . 'images/icon-profile-grid.png'; ?>" width=120px;></div>
	   <!-- right column -->
	  <div class="col-dpwap-8">
	  <h4>ProfileGrid – User Profiles, Groups and Communities</h4>
       <p>Create frontend user profiles, groups, communities, paid memberships, directories, WooCommerce user profiles and bbPress profiles, restrict... 
       </p>
      </div>
	</div>
<?php } ?>	
<?php if($feature4==1) { ?>
    <div class="row">
    	<input type="hidden" id="event_prime" name="event_prime" value="1"> 	
	   <!-- left column -->
	  <div class="col-dpwap-4"><img src="<?php echo plugin_dir_url( __FILE__ ) . 'images/icon-event-prime.png'; ?>" width=120px;></div>
	   <!-- right column -->
	  <div class="col-dpwap-8">
	  <h4>EventPrime – Event Calendar Management</h4>
       <p>EventPrime is an easy to use, beginner-friendly WordPress Event Calendar Management plugin which empowers you with the ability to...
       </p>
      </div>
	</div>
<?php } ?>	