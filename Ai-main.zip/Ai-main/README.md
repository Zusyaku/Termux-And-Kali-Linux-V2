        
![asu](https://img.shields.io/badge/Code-POLYGON-green)
![asu](https://img.shields.io/badge/Made-INDONESIA-red)                             
![asu](https://img.shields.io/badge/Program-Bash-blue)


```perl
--------------------------------------------
           =>[ code by polygon ]<=

--help,     -h  | bantuan
        --wiki  | wikipedia
       --surah  | al-baqarah
       --credit | credit author
-Y,   --youtube | youtube author

---------------------------------------------
```

# License

```
MIT License

Copyright (c) 2021 COINTER-TEAM

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

# how to install

```bash
>> apt update
>> apt full-upgrade
>> apt install gawk
>> apt install jq
>> apt install which
>> apt install whiptail
>> apt install html2text
>> apt install lynx curl
>> apt install dialog
>> apt install pv
>> apt install git
>> git clone https://github.com/COINTER-team/Ai
>> cd Ai
>> bash Ai.sh
```
            
![asu](https://img.shields.io/badge/ME-Youtube-yellow)
# [youtube](https://youtube.com/channel/UCtu-GcxKL8kJBXpR1wfMgWg)
