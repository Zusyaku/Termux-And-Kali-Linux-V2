cyn='\e[0;36m'

lgrn='\e[1;32m'

r='\e[1;31m'

y='\e[1;33m'
################
echo ' 
 
                 _|    _|            _|  _|            
                 _|    _|    _|_|    _|  _|    _|_|    
                 _|_|_|_|  _|_|_|_|  _|  _|  _|    _|  
                 _|    _|  _|        _|  _|  _|    _|  
                 _|    _|    _|_|_|  _|  _|    _|_|' | lolcat
echo " "
echo " "
cat letter.txt
echo " "
echo "                      " ✿♥✿░T░H░A░N░K░S░✿♥✿ | lolcat
echo " " 
echo " "
sleep 16.0
clear 
exit 0 
