Themes can be created by using the template included in this directory.

For people downloading themes, Please be careful, as themes can execute code. The themes downloaded from my repository will always be checked by me,
but for themes shared around Discord etc., be weary of what may be hiding inside it.
