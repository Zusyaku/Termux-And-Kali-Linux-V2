
[![Python 3.5](https://img.shields.io/badge/Python-3.5-yellow.svg)](http://www.python.org/download/) 


# WebKiller V2

Tool Information Gathering Write With Python.


## PreView
<pre>

    
 ██╗    ██╗███████╗██████╗ ██╗  ██╗██╗██╗     ██╗     ███████╗██████╗ 
 ██║    ██║██╔════╝██╔══██╗██║ ██╔╝██║██║     ██║     ██╔════╝██╔══██╗
 ██║ █╗ ██║█████╗  ██████╔╝█████╔╝ ██║██║     ██║     █████╗  ██████╔╝
 ██║███╗██║██╔══╝  ██╔══██╗██╔═██╗ ██║██║     ██║     ██╔══╝  ██╔══██╗
 ╚███╔███╔╝███████╗██████╔╝██║  ██╗██║███████╗███████╗███████╗██║  ██║
 ╚══╝╚══╝ ╚══════╝╚═════╝ ╚═╝  ╚═╝╚═╝╚══════╝╚══════╝╚══════╝╚═╝  ╚═╝
 ====================================================================
 **                  WebSite : UltraSec.org                        **
 **                  Channel : @UltraSecurity                      **
 **                 Developers : Ultra Security Team                            **
 **               Team Members : Ashkan Moghaddas , Behzad Khalifeh , AmirMohammad Safari           **
 **                   Thank's : .::Shayan::.                       **
 ====================================================================          
          
 [卐] Choose one of the options below 

 [1] Information Gathering

 [2] CMS Detection

 [3] Developer :)

 [4] Exit . . .

 ┌─[WEBKILLER~@HOME]
 └──╼ 卐 


</pre>


## Operating Systems Tested
- Kali Linux 2020.1
- Windows 10
- Ubuntu 19.10


## Install
```bash
git clone https://github.com/ultrasecurity/webkiller.git
cd webkiller
pip3 install -r requirements.txt
python3 webkiller.py 
```

## ScreenShot
![webkiller](http://uupload.ir/files/otmb_webkiller.jpg)

## Video Tutorial
Youtube : https://www.youtube.com/watch?v=MTaM1YX8QsE


### Thanks to
    Ashkan Moghaddas - Ultra Security Team Leader
    Behzad Khalifeh- Ultra Security Team Programmer
    AmirMohammad Safari - WebApplication Pentester 
     

### Contact us
- WebSite Ultra Security Team : https://ultrasec.org
- Channel Telegram : https://t.me/UltraSecurity

