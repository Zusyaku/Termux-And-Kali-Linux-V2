#!/data/data/com.termux/files/usr/bin/bash
@Author VivekXD
#Date --- 24 jan 2021

cd 
cd ..
cd usr/etc
mv backup_TB/* .
cd
cd .termux 
rm -rf colors.properties
