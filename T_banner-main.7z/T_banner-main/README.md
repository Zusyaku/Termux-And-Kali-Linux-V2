# T_banner

![made in india](https://img.shields.io/badge/MADE%20IN%20-INDIA-green?style=for-the-badge&logo=appveyor)
![Vivek Chandel](https://img.shields.io/badge/Vivek%20-Chandel-green?style=for-the-badge&logo=appveyor)

![GitHub followers](https://img.shields.io/github/followers/MRVIVEK-CODER?style=for-the-badge)
![Twitter Follow](https://img.shields.io/twitter/follow/vivek_chandel?color=%23ff128c&label=%40VivekXD&style=for-the-badge)
---
![20210125_063051](https://user-images.githubusercontent.com/56459297/105649622-f0bf1900-5ed6-11eb-84b6-e4405bfbc3e1.png)

## Installation on termux---
```
1. git clone https://github.com/MRVIVEK-CODER/T_banner.git
2. cd T_banner
3. chmod +x *
4. ./banner.sh

```
### One line cmd 
```
git clone https://github.com/MRVIVEK-CODER/T_banner.git;cd T_banner;chmod +x *;bash banner.sh 
```
### Termux -- look

![20210124_214804](https://github.com/MRVIVEK-CODER/T_banner/blob/main/IMG-20210611-WA0079.jpg)

## [Youtube](https://youtube.com/c/TechnicalVivekTricker420)

## [Instagram](https://instagram.com/sirprincekrvert)
### [Read blog-post](https://technicalviv3k.blogspot.com/2021/06/how-to-style-termux-promptbackgroundosl.html?m=1)
