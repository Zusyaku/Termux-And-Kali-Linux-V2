<h1 align="center">
  stopwatch
</h1>
</div>
<p align="center">
  Made with ❤️ by <a href="https://github.com/Bayu12345677">Bayu12345677_</a>
</p>
<p align="center">
 
## install
```lua

$ apt update
$ apt full-upgrade
$ apt install git
$ apt install ncurses-utils
$ git clone https://github.com/COINTER-team/stopwatch
$ cd stopwatch
$ bash hitung.sh

```


> Script open source jadi jangan lupa support YT saya Pejuang kentang

## Team
```php
 COINTER-TEAM
 Helixs-crew
```

> Jangan lupa subscribe tod
> script ini saya buat open source :v
