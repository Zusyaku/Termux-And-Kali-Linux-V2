#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# pylint: skip-file

ALL_2G_CHANNELS = list(range(1, 14))
