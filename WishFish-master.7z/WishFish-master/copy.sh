#! /bin/sh
cp -r captured ../storage/pictures/
