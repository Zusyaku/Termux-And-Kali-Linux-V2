from pymeta import main
main()