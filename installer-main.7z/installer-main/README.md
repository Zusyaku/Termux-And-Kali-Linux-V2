# Installer

## Install Termux Basic packages

#### Commands:

```apt update && apt upgrade -y```

```apt install git```

```termux-setup-storage```

```git clone https://github.com/KasRoudra/installer```

```cd installer```

```chmod +x install.sh```

```bash install.sh```

#### Complete!

### Partial script from <a href="https://github.com/Cabbagec/termux-ohmyzsh">Termux-OhMyZsh</a>