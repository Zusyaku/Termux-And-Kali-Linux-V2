## Readme
**INFO.**
* *Not* all domains will have *subdomains*.
* *Not* all domains will *leak dns information*.
* *Some text files*, if such a thing is **true** for that current domain will output an *empty* file.
* You will get **all** the **information** eg *subdomains*, *dns records* & *More!* that can be got from each said domain.
