# SQLVuln

Simple tool to scanning sql injection vulnerability, easy to use!!

# install



**Using sqlvuln python, available for linux and termux (android)**
```
$apt install pyton3 git -y
$git clone https://github.com/Ranginang67/SQLVuln
$cd SQLVuln
$python3 sqlvuln.py
```



**Using sqlvuln c++, available for linux only**

```
$sudo apt-get install git
$git clone https://github.com/Ranginang67/SQLVuln
$cd SQLVuln
$chmod +x *.sh
$./install.sh main.cpp
$./dork
```

<br>
Note: select language you want to use :D
