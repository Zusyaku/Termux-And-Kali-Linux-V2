go build ./
sudo cp ./netscanner /usr/local/bin
netscanner
