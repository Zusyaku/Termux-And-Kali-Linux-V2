<h1 align="center">
  OSINT TOOLS
</h1>
</div>
<p align="center">
  Made with ⌨ by <a href="https://github.com/Bayu12345677">POLYGON</a>
</p>
<p align="center">
<img src="https://img.shields.io/badge/Program-Bash-blue" width="110" title="Menu" alt="Menu">
</p>
<p align="center">
<img src="https://img.shields.io/badge/Made-INDONESIA-red" width="210" title="menu" alt="menu">
</p>

# Tampilan
![aowkwk](https://github.com/Bayu12345677/Osint/blob/main/20211107_144257.png)


<h1 align="center">
   How to install
</h1>
</div>

```php
$ apt update
$ apt full-upgrade
$ apt install toilet
$ apt install git
$ git clone https://github.com/COINTER-team/Osint
$ cd Osint
$ bash setup.txt
$ bash Osint.sh
```

```python
Team : COINTER & HELIXS CREW
supporter : Aldi, Abdul, Panglima jateng,
            dan seluruh team Helixs crew dan Cointer
```



`ME SOCIAL MEDIA`                    
[• Youtube](https://m.youtube.com/channel/UCtu-GcxKL8kJBXpR1wfMgWg)                 
• whatsapp : 085731184377

> BLOG HELIXS Crew                                   
[• helixs](https://helixs.id)

<h1 align="center">
   Terimkasi telah berkunjung :)
</h1>
</div>
