![Logo-Makr-12hrnk.png](https://i.postimg.cc/SR4vXjjq/Logo-Makr-12hrnk.png)

# PhishMailer


**Coded By BiZken**

Special Thanks To Fanny Hasbi For helping Me With The Code Structure: https://github.com/fannyhasbi 

PhishMailer Will Help You To Create Professional Phishing Emails Fast And Easy

#### If You Copy The Code And Make Your Own, Don't forget To Give Me Some Credit Kid!

## You Don't Get Creds Using This Tool 

## Legal Disclaimer
I Won't Say That You Can Only Use This Tool For Educational Purposes And That You Can't Use It To Hack Other People
Because I Have used It To Hack Others But Remember That It Is Illegal To Do It So If You Get Caught You're On Your Own
Don't Come To Me And Blame Me For It

### Features
* Phishing Email Creator With 20 Different Templates: 
  * Instagram
  * Facebook
  * Gmail(2)
  * Twitter
  * Paypal
  * Snapchat(2)
  * Spotify
  * Linkedin
  * Discord
  * Dropbox
  * Steam
  * RiotGames (League Of Legends)
  * Rockstar SocialClub
  * BlockChain
  * DreamTeam
  * 000Webhosting
  * AskFM
  * Gamehag
#### And More Are On The Way
* Creates .HTML
* Send your emails to your target
* Easy To Use

<a href="https://ibb.co/HTGXTNB"><img src="https://i.ibb.co/8gPXgzN/phishmailer-main-menu-2-0.png" alt="phishmailer-main-menu-2-0" border="0"></a>

#### Gmail (Simple) Result:
<a href="https://ibb.co/kSjzn5s"><img src="https://i.ibb.co/hmbr5LJ/Gmail-github.png" alt="Gmail-github" border="0"></a>

## Install
**You Need Python3**

**Tested On Kali Linux**

First Clone The Repostory With "git clone"
```bash
git clone https://www.github.com/BiZken/PhishMailer.git
```
Then Go To The PhishMailer Folder And Change Permission On "PhishMailer" (If You Ain't Root)
```python
chmod +x PhishMailer.py
```
And then Run it:
```Run
python3 PhishMailer.py
```
## To Do
- [x] Send Emails
- [x] Add More Email Templates
- [ ] Add More Target Specified Emails, With Profile Pictures for example
- [ ] Add Emails With More Languages 
- [ ] Mass Email Sender
- [x] Fix More Email Clients To Send From

## Contact
If You Have Any Ideas And/Or Have Created Some Phishing Email(s) And Want To Have Your Name Here As A Code Helper
You Can Contact Me Here:
Instagram: bizk3n

## Support 
If You Want To Support Me So I Can Continue And Update PhishMailer And Create Other Hacking Tools
You Can Do That Here:
[!["Buy Me A Coffee"](https://www.buymeacoffee.com/assets/img/custom_images/orange_img.png)](https://www.buymeacoffee.com/BiZken)
