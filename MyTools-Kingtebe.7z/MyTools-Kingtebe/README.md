## Info
```
Script sederhana yang berisi dari beberapa tools
mulai dari scanner, spaming, shortlink, information
semoga bermanfaat ^_^
```
## MyTools
![screen](https://github.com/Kingtebe/MyTools/blob/Kingtebe/lib/MyTools.jpg)
## Installasi
```php
$ pkg update && pkg upgrade
$ pkg install git
$ pkg install python
$ git clone https://github.com/Kingtebe/MyTools
$ cd MyTools
$ pip install -r requirements.txt
$ python tools.py
```
## Feature
- [x] Admin Finder
- [x] Subdomain Scanner
- [x] Extract Page Site
- [x] Random Quotes
- [x] Create Sandi Password
- [x] Check My Ip Addres
- [x] IpLocation Tracker
- [x] Spaming Call
- [x] Spaming Sms
- [x] Short Url / Pemendek Url
- [x] Phone Number Information
- [x] Information Gempa

