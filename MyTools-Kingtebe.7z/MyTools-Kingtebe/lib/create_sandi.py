
UNGU = '\033[95m'
BIRU = '\033[94m'
HIJAU = '\033[92m'
KUNING = '\033[93m'
MERAH = '\033[91m'
ENDC = '\033[0m'
BOLD = '\033[97m'
EBLE = '\033[2;34m'

class Sandi:

	def __init__(self):
		try:
			list_password = ['1','2','3','4','5','6','7','8','9','0','A','B','C','D','E','F','G','H','I','J','K','L','M','N',  'O','P','Q','R','S','T','U','V','W','X','Y','Z','a','b','c','d','e','f','g','h','i','j','k','l','m','n', 'o','p','q','r','s','t','u','v','w','x','y','z']
			pwd = input("\n     {}[{}•{}] Input Kata : ".format(BOLD,EBLE,ENDC,BOLD));paw = " "
			enx = 7
			for coli in range(len(pwd)):
				temp = list_password.index(pwd[coli]) + enx
				paw = paw + list_password[temp%63]
			print('\n     {}[{}+{}] Result Kata =>{}{}'.format(BOLD,KUNING,BOLD,KUNING,paw)+"\n")

		except ValueError:
			print("\n     Don`t Use Spaces \n");exit()
		except IndexError:
			print("\n     Goblokkkkkk \n");exit()

