import requests
import json

UNGU = '\033[95m'
BIRU = '\033[94m'
HIJAU = '\033[92m'
KUNING = '\033[93m'
MERAH = '\033[91m'
ENDC = '\033[0m'
BOLD = '\033[97m'
EBLE = '\033[2;34m'

class Ip:

	def __init__(self):
		self.kopit = requests.Session()
		self.Main()

	def Main(self):
		try:
			ip = input("\n     {}[{}•{}] Ip Address : ".format(BOLD,EBLE,ENDC,BOLD))
			self.web = self.kopit.get("https://ipinfo.io/{}/json".format(ip))
			self.find = json.loads(self.web.text)
			print("\n     {}[{}+{}] Ip       : {}{}".format(BOLD,KUNING,BOLD,KUNING,self.find['ip']))
			print("     {}[{}+{}] City     : {}{}".format(BOLD,KUNING,BOLD,KUNING,self.find['city']))
			print("     {}[{}+{}] State    : {}{}".format(BOLD,KUNING,BOLD,KUNING,self.find['region']))
			print("     {}[{}+{}] Country  : {}{}".format(BOLD,KUNING,BOLD,KUNING,self.find['country']))
			print("     {}[{}+{}] Latitude : {}{}".format(BOLD,KUNING,BOLD,KUNING,self.find['loc']))
			print("     {}[{}+{}] Timezone : {}{}".format(BOLD,KUNING,BOLD,KUNING,self.find['timezone'])+"\n")

		except:
			pass
