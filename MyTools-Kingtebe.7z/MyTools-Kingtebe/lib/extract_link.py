import requests

UNGU = '\033[95m'
BIRU = '\033[94m'
HIJAU = '\033[92m'
KUNING = '\033[93m'
MERAH = '\033[91m'
ENDC = '\033[0m'
BOLD = '\033[97m'
EBLE = '\033[2;34m'

class Link:

	def __init__(self):
		self.kopit = requests.Session()
		self._Page()

	def _Page(self):
		try:
			link = str(input("\n     {}[{}•{}] Link Web : ".format(BOLD,EBLE,ENDC,BOLD)));print("{}".format(KUNING))
			self.api = self.kopit.get("https://api.hackertarget.com/pagelinks/?q={}".format(link))
			print(self.api.text)
		except:
			pass
