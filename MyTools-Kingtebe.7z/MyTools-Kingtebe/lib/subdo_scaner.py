import requests, json, time

UNGU = '\033[95m'
BIRU = '\033[94m'
HIJAU = '\033[92m'
KUNING = '\033[93m'
MERAH = '\033[91m'
ENDC = '\033[0m'
BOLD = '\033[97m'
EBLE = '\033[2;34m'

class Subdo:

	def __init__(self):
		self.kopit = requests.Session()
		self.scan()

	def scan(self):
		try:
			site = str(input("\n     {}[{}•{}] Url Domain : ".format(BOLD,EBLE,ENDC,BOLD)));time.sleep(2)
			self.api = self.kopit.get("http://jamet1337.ml/api/subdo.php?url={}".format(site))
			self.find = json.loads(self.api.text)
			print("\033[93m"+self.find['hasil']+'\n')

		except:
			pass

