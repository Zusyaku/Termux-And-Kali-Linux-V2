import requests
import json

UNGU = '\033[95m'
BIRU = '\033[94m'
HIJAU = '\033[92m'
KUNING = '\033[93m'
MERAH = '\033[91m'
ENDC = '\033[0m'
BOLD = '\033[97m'
EBLE = '\033[2;34m'

class Phone:

	def __init__(self):
		self.kopit = requests.Session()
		self.scanphone()

	def scanphone(self):
		try:
			phone = input("\n     {}[{}•{}] Enter Number : ".format(BOLD,EBLE,ENDC,BOLD))
			self.web = self.kopit.get("https://api.veriphone.io/v2/verify?phone={}&key=5F3F2D6300E445DEA88684053144966C".format(phone))
			self.js = json.loads(self.web.text)

			print("\n     {}[{}+{}] Type     : {}{}".format(BOLD,KUNING,BOLD,KUNING,self.js['phone_type']))
			print("     {}[{}+{}] Code     : {}{}".format(BOLD,KUNING,BOLD,KUNING,self.js['country_code']))
			print("     {}[{}+{}] Prefix   : {}{}".format(BOLD,KUNING,BOLD,KUNING,self.js['country_prefix']))
			print("     {}[{}+{}] Country  : {}{}".format(BOLD,KUNING,BOLD,KUNING,self.js['country']))
			print("     {}[{}+{}] Global   : {}{}".format(BOLD,KUNING,BOLD,KUNING,self.js['international_number']))
			print("     {}[{}+{}] Local    : {}{}".format(BOLD,KUNING,BOLD,KUNING,self.js['local_number']))
			print("     {}[{}+{}] Provider : {}{}".format(BOLD,KUNING,BOLD,KUNING,self.js['carier'])+"\n")

		except:
			pass;print("")
