import requests
import json

UNGU = '\033[95m'
BIRU = '\033[94m'
HIJAU = '\033[92m'
KUNING = '\033[93m'
MERAH = '\033[91m'
ENDC = '\033[0m'
BOLD = '\033[97m'
EBLE = '\033[2;34m'

class quote:

	def __init__(self):
		self.exe = requests.Session()
		self.web = "https://mhankbarbar.herokuapp.com/api/randomquotes"
		self.Main()

	def Main(self):
		try:
			self.api = self.exe.get(self.web).text
			self.js = json.loads(self.api)
			print("\n     {}[{}+{}] \033[97mAuthor : \033[93m{}".format(BOLD,KUNING,BOLD,self.js['author']))
			print("     {}[{}+{}] \033[97mQuotes : \033[93m{}".format(BOLD,KUNING,BOLD,self.js['quotes'])+"\n")
		except:
			pass

