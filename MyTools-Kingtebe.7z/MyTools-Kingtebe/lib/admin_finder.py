import requests

UNGU = '\033[95m'
BIRU = '\033[94m'
HIJAU = '\033[92m'
KUNING = '\033[93m'
MERAH = '\033[91m'
ENDC = '\033[0m'
BOLD = '\033[97m'
EBLE = '\033[2;34m'

class Admin:

	def __init__(self):
		self.kopit = requests.Session()
		self._Original()

	def _Original(self):
		try:
			f = open("scan.txt","r").read()
			xixi = f.split('\n')
			target = input("\n     {}[{}•{}] Site name : ".format(BOLD,EBLE,ENDC,BOLD));print("")

			for i in xixi:
				url = target+"/"+i
				code = requests.get(str(url)).status_code
				if code == 200:
					print("     {}[{}✓{}] {}Berhasil {}| {}url : {}".format(BOLD,HIJAU,BOLD,HIJAU,ENDC,BOLD,KUNING)+url)
				else:
					print("     {}[{}!{}] {}Gagal {}| {}url : {}".format(BOLD,MERAH,BOLD,MERAH,ENDC,BOLD,KUNING)+url)
		except:
			pass;print("")
