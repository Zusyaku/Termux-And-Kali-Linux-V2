import socket
from requests import get

UNGU = '\033[95m'
BIRU = '\033[94m'
HIJAU = '\033[92m'
KUNING = '\033[93m'
MERAH = '\033[91m'
ENDC = '\033[0m'
BOLD = '\033[97m'
EBLE = '\033[2;34m'

class My:

	def __init__(self):
		self.Main()

	def Main(self):
		try:
			hostname = socket.gethostname()
			ipaddress = get("https://api.ipify.org").text
			print("\n     {}[{}+{}] Your Hostname   : {}{}".format(BOLD,KUNING,BOLD,KUNING,hostname))
			print("     {}[{}+{}] Your Ip Address : {}{}".format(BOLD,KUNING,BOLD,KUNING,ipaddress)+"\n")
		except:
			pass

