import requests
from bs4 import BeautifulSoup as bs

UNGU = '\033[95m'
BIRU = '\033[94m'
HIJAU = '\033[92m'
KUNING = '\033[93m'
MERAH = '\033[91m'
ENDC = '\033[0m'
BOLD = '\033[97m'
EBLE = '\033[2;34m'

class Gempa:

	def __init__(self):
		self.kopit = requests.Session()
		self.url = "https://www.bmkg.go.id"
		self.Info()

	def Info(self):
		try:
			get = self.kopit.get(self.url)
			scrap = bs(get.text, "html.parser")
			all = scrap.find("div", class_="col-md-4 md-margin-bottom-10")
			req = all.findAll("li")
			map = all.find("a")["href"]

#			print('\n Map : {}'.format(map))
			print('\n     {}[{}+{}] Waktu : {}{}'.format(BOLD,KUNING,BOLD,KUNING,req[0].text))
			print('\n     {}[{}+{}] Magnitude : {}{}'.format(BOLD,KUNING,BOLD,KUNING,req[1].text))
			print('     {}[{}+{}] Kedalaman : {}{}'.format(BOLD,KUNING,BOLD,KUNING,req[2].text))
			print('     {}[{}+{}] Koordinat : {}{}'.format(BOLD,KUNING,BOLD,KUNING,req[3].text))
			print('\n     {}[{}+{}] Lokasi : {}{}'.format(BOLD,KUNING,BOLD,KUNING,req[4].text))
			print('     {}[{}+{}] Potensi : {}{}'.format(BOLD,KUNING,BOLD,KUNING,req[5].text)+"\n")
		except:
			pass

