import requests, time
import json

UNGU = '\033[95m'
BIRU = '\033[94m'
HIJAU = '\033[92m'
KUNING = '\033[93m'
MERAH = '\033[91m'
ENDC = '\033[0m'
BOLD = '\033[97m'
EBLE = '\033[2;34m'

class Sms:

	def __init__(self):
		self.kopit = requests.Session()
		self.web = "https://api.harnicid.com/phone_auth_OTP"
		self.gas()

	def gas(self):
		try:
			print("\n     {}[{}!{}] Example : \033[93m08212xxxx".format(BOLD,EBLE,ENDC,BOLD))
			phone = input("     {}[{}•{}] Enter Number : ".format(BOLD,EBLE,ENDC,BOLD));print("")
			for coli in range(3):
				self.api = self.kopit.post(self.web,data={"phone":"{}".format(phone)},headers={"user-agent": "Mozilla/5.0 (Linux; Android 8.1.0; CPH1853) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.106 Mobile Safari/537.36"})
				if self.api == "OTP Sent":
					print(f"     {BOLD}[{MERAH}!{BOLD}] Sms To {KUNING}"+ phone +f"{MERAH} Limit!")
					time.sleep(1.7)
				else:
					print(f"     {BOLD}[{HIJAU}✓{BOLD}] Sms To {KUNING}"+ phone +f"{HIJAU} Berhasil!")
					time.sleep(1.7)
		except:
			pass

		print("\n     {}[{}•{}] Done ...\n".format(BOLD,EBLE,ENDC,BOLD));exit()
